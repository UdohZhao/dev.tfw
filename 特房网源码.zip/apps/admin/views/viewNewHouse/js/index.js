function detail_info(id){
    window.location.href='/admin/viewNewHouse/view_house?id='+id;
}

// 新房详细信息
function nhInfo(id){
    window.location.href='/admin/viewNewHouse/houseInfo?nhcid='+id;
}

// 新房主力户型
function nhmInfo(id){
    window.location.href='/admin/viewNewHouse/mainUser?nhcid='+id;
}