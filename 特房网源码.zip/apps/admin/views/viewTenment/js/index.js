function detail_info(id){
    window.location.href='/admin/viewTenment/detail_info?id='+id;
}

// 新房详细信息
function checkHouse(id){
    window.location.href='/admin/viewTenment/houseInfo?id='+id;
}