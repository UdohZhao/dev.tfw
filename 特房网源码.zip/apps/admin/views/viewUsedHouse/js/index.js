
//审核
function detail_info(id){
    window.location.href='/admin/viewUsedHouse/view_house?id='+id;
}

// 新房详细信息
function uhInfo(id){
    window.location.href='/admin/viewUsedHouse/houseDetail/uhcid/'+id;
}
