<?php
namespace apps\home\model;
use core\lib\model;
class demoModel extends model{

  public function add(){

    // code

  }

}

