<?php
return array(
  // 必须配置项
  'database_type' => 'mysql',
  'database_name' => 'house_asset',
  'server' => '112.74.46.113',
  'username' => 'iego',
  'password' => 'iego',
  'charset' => 'utf8',
);