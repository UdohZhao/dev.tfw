<?php
return array(
    'DRIVE' =>  'file',
    'OPTION'  =>  array(
        'PATH'  =>  ICUNJI.'/log/',
    ),
);