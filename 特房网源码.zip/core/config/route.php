<?php
return array(
  'CTRL'  =>  'index',
  'ACTION'  =>  'index'
);