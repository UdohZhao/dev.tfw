<?php

/* newHouseCatalog/add.html */
class __TwigTemplate_89b68cce583febf80d6b35925ff154fa28a515b2f1561b5864549ecc162828f9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.html", "newHouseCatalog/add.html", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
            'js' => array($this, 'block_js'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "<link rel=\"stylesheet\" href=\"/public/webuploader-0.1.5/dist/webuploader.css\">
<link rel=\"stylesheet\" type=\"text/css\" href=\"/public/webuploader-0.1.5/examples/image-upload/style.css\" />
";
    }

    // line 6
    public function block_content($context, array $blocks = array())
    {
        // line 7
        echo "<!-- Page -->
<div class=\"page animsition\">
  <div class=\"page-header\">
    <h1 class=\"page-title\"># 房屋管理</h1>
  </div>
  <div class=\"page-content\">
    <div class=\"panel\">
      <div class=\"panel-heading\">
        <h3 class=\"panel-title\">@ 添加新房条目</h3>
      </div>
      <div id=\"wrapper\">
          <div id=\"container\">
              <!--头部，相册选择和格式选择-->
              <div id=\"uploader\">
                  <div class=\"queueList\">
                      <div id=\"dndArea\" class=\"placeholder\">
                          <div id=\"filePicker\"></div>
                          <p>请选择需要上传的轮播图片，单次最多可选300张</p>
                      </div>
                  </div>
                  <div class=\"statusBar\" style=\"display:none;\">
                      <div class=\"progress\">
                          <span class=\"text\">0%</span>
                          <span class=\"percentage\"></span>
                      </div><div class=\"info\"></div>
                      <div class=\"btns\">
                          <div id=\"filePicker2\"></div><div class=\"uploadBtn\">开始上传</div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
      <div class=\"panel-body\">
        <form class=\"form-horizontal\" id=\"newHouseCatalogForm\" action=\"/admin/newHouseCatalog/add/id/";
        // line 40
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "id", array()), "html", null, true);
        echo "\" method=\"post\">
        <input type=\"hidden\" name=\"hcid\" value=\"";
        // line 41
        echo twig_escape_filter($this->env, ($context["hcid"] ?? null), "html", null, true);
        echo "\">
        <input type=\"hidden\" name=\"pid\" value=\"";
        // line 42
        echo twig_escape_filter($this->env, ($context["pid"] ?? null), "html", null, true);
        echo "\">
        <input type=\"hidden\" name=\"slideshow\" value=\"";
        // line 43
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "slideshow", array()), "html", null, true);
        echo "\">
          <div class=\"form-group\">
            <label for=\"inputEmail3\" class=\"col-sm-2 control-label\">关联城市</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"cid\" value=\"";
        // line 47
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "cid", array()), "html", null, true);
        echo "\" placeholder=\"请输入城市名称\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">标题</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"title\" value=\"";
        // line 53
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "title", array()), "html", null, true);
        echo "\" placeholder=\"请输入标题\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">小区</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"community\" value=\"";
        // line 59
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "community", array()), "html", null, true);
        echo "\" placeholder=\"请输入小区\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">价格</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"price\" value=\"";
        // line 65
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "price", array()), "html", null, true);
        echo "\" placeholder=\"请输入总价格\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">展示价格</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"show_price\" value=\"";
        // line 71
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "show_price", array()), "html", null, true);
        echo "\" placeholder=\"请输入展示价格(带单位)\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">特点</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"trait\" value=\"";
        // line 77
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "trait", array()), "html", null, true);
        echo "\" placeholder=\"请输入特点（以英文逗号分隔）例如：AAA,BBB,CCC\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">面积</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"area\" value=\"";
        // line 83
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "area", array()), "html", null, true);
        echo "\" placeholder=\"请输入面积\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">地址</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"address\" value=\"";
        // line 89
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "address", array()), "html", null, true);
        echo "\" placeholder=\"请输入地址\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">备注</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"remark\" value=\"";
        // line 95
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "remark", array()), "html", null, true);
        echo "\" placeholder=\"请输入需要备注的信息\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">户型</label>
            <div class=\"col-sm-10\">
            ";
        // line 101
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["htype"] ?? null));
        foreach ($context['_seq'] as $context["k"] => $context["v"]) {
            // line 102
            echo "              <label class=\"checkbox-inline\">
                ";
            // line 103
            if (twig_in_filter($context["v"], twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "htype", array()))) {
                // line 104
                echo "                  <input type=\"checkbox\" id=\"htype\" checked name=\"htype[]\" value=\"";
                echo twig_escape_filter($this->env, $context["v"], "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $context["v"], "html", null, true);
                echo "
                ";
            } else {
                // line 106
                echo "                  <input type=\"checkbox\" id=\"htype\" name=\"htype[]\" value=\"";
                echo twig_escape_filter($this->env, $context["v"], "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $context["v"], "html", null, true);
                echo "
                ";
            }
            // line 108
            echo "              </label>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['k'], $context['v'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 110
        echo "            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">产权类型</label>
            <div class=\"col-sm-10\">
            ";
        // line 115
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["prtype"] ?? null));
        foreach ($context['_seq'] as $context["k"] => $context["v"]) {
            // line 116
            echo "              <label class=\"radio-inline\">
                ";
            // line 117
            if (((twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "prtype", array()) == $context["k"]) && twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "prtype", array(), "any", true, true))) {
                // line 118
                echo "                  <input type=\"radio\" name=\"prtype\" checked value=\"";
                echo twig_escape_filter($this->env, $context["k"], "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $context["v"], "html", null, true);
                echo "
                ";
            } else {
                // line 120
                echo "                <input type=\"radio\" name=\"prtype\" value=\"";
                echo twig_escape_filter($this->env, $context["k"], "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $context["v"], "html", null, true);
                echo "
                ";
            }
            // line 122
            echo "              </label>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['k'], $context['v'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 124
        echo "            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">房屋类型</label>
            <div class=\"col-sm-10\">
            ";
        // line 129
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["house_type"] ?? null));
        foreach ($context['_seq'] as $context["k"] => $context["v"]) {
            // line 130
            echo "              <label class=\"radio-inline\">
                ";
            // line 131
            if (((twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "house_type", array()) == $context["k"]) && twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "house_type", array(), "any", true, true))) {
                // line 132
                echo "                  <input type=\"radio\" checked name=\"house_type\" value=\"";
                echo twig_escape_filter($this->env, $context["k"], "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $context["v"], "html", null, true);
                echo "
                ";
            } else {
                // line 134
                echo "                  <input type=\"radio\"  name=\"house_type\" value=\"";
                echo twig_escape_filter($this->env, $context["k"], "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $context["v"], "html", null, true);
                echo "
                ";
            }
            // line 136
            echo "              </label>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['k'], $context['v'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 138
        echo "            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">物业类型</label>
            <div class=\"col-sm-10\">
            ";
        // line 143
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["ptype"] ?? null));
        foreach ($context['_seq'] as $context["k"] => $context["v"]) {
            // line 144
            echo "              <label class=\"checkbox-inline\">
                ";
            // line 145
            if (twig_in_filter($context["v"], twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "ptype", array()))) {
                // line 146
                echo "                  <input type=\"checkbox\" id=\"ptype\" checked name=\"ptype[]\" value=\"";
                echo twig_escape_filter($this->env, $context["v"], "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $context["v"], "html", null, true);
                echo "
                ";
            } else {
                // line 148
                echo "                <input type=\"checkbox\" id=\"ptype\" name=\"ptype[]\" value=\"";
                echo twig_escape_filter($this->env, $context["v"], "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $context["v"], "html", null, true);
                echo "
                ";
            }
            // line 150
            echo "              </label>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['k'], $context['v'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 152
        echo "            </div>
          </div>
          <div class=\"form-group\">
            <div class=\"col-sm-offset-2 col-sm-10\">
              <button type=\"submit\" class=\"btn btn-success\">下一步</button>
            </div>
          </div>
        </form>

      </div>
    </div>
  </div>
</div>
<!-- End Page -->
";
    }

    // line 167
    public function block_js($context, array $blocks = array())
    {
        // line 168
        echo "<script src=\"/public/webuploader-0.1.5/dist/webuploader.js\"></script>
<script type=\"text/javascript\" src=\"/public/webuploader-0.1.5/examples/image-upload/upload.js\"></script>
<script src=\"/apps/admin/views/newHouseCatalog/js/add.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "newHouseCatalog/add.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  347 => 168,  344 => 167,  326 => 152,  319 => 150,  311 => 148,  303 => 146,  301 => 145,  298 => 144,  294 => 143,  287 => 138,  280 => 136,  272 => 134,  264 => 132,  262 => 131,  259 => 130,  255 => 129,  248 => 124,  241 => 122,  233 => 120,  225 => 118,  223 => 117,  220 => 116,  216 => 115,  209 => 110,  202 => 108,  194 => 106,  186 => 104,  184 => 103,  181 => 102,  177 => 101,  168 => 95,  159 => 89,  150 => 83,  141 => 77,  132 => 71,  123 => 65,  114 => 59,  105 => 53,  96 => 47,  89 => 43,  85 => 42,  81 => 41,  77 => 40,  42 => 7,  39 => 6,  33 => 3,  30 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layouts.html\" %}
{% block css %}
<link rel=\"stylesheet\" href=\"/public/webuploader-0.1.5/dist/webuploader.css\">
<link rel=\"stylesheet\" type=\"text/css\" href=\"/public/webuploader-0.1.5/examples/image-upload/style.css\" />
{% endblock %}
{% block content %}
<!-- Page -->
<div class=\"page animsition\">
  <div class=\"page-header\">
    <h1 class=\"page-title\"># 房屋管理</h1>
  </div>
  <div class=\"page-content\">
    <div class=\"panel\">
      <div class=\"panel-heading\">
        <h3 class=\"panel-title\">@ 添加新房条目</h3>
      </div>
      <div id=\"wrapper\">
          <div id=\"container\">
              <!--头部，相册选择和格式选择-->
              <div id=\"uploader\">
                  <div class=\"queueList\">
                      <div id=\"dndArea\" class=\"placeholder\">
                          <div id=\"filePicker\"></div>
                          <p>请选择需要上传的轮播图片，单次最多可选300张</p>
                      </div>
                  </div>
                  <div class=\"statusBar\" style=\"display:none;\">
                      <div class=\"progress\">
                          <span class=\"text\">0%</span>
                          <span class=\"percentage\"></span>
                      </div><div class=\"info\"></div>
                      <div class=\"btns\">
                          <div id=\"filePicker2\"></div><div class=\"uploadBtn\">开始上传</div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
      <div class=\"panel-body\">
        <form class=\"form-horizontal\" id=\"newHouseCatalogForm\" action=\"/admin/newHouseCatalog/add/id/{{ data.id }}\" method=\"post\">
        <input type=\"hidden\" name=\"hcid\" value=\"{{ hcid }}\">
        <input type=\"hidden\" name=\"pid\" value=\"{{ pid }}\">
        <input type=\"hidden\" name=\"slideshow\" value=\"{{ data.slideshow }}\">
          <div class=\"form-group\">
            <label for=\"inputEmail3\" class=\"col-sm-2 control-label\">关联城市</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"cid\" value=\"{{ data.cid }}\" placeholder=\"请输入城市名称\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">标题</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"title\" value=\"{{ data.title }}\" placeholder=\"请输入标题\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">小区</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"community\" value=\"{{ data.community }}\" placeholder=\"请输入小区\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">价格</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"price\" value=\"{{ data.price }}\" placeholder=\"请输入总价格\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">展示价格</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"show_price\" value=\"{{ data.show_price }}\" placeholder=\"请输入展示价格(带单位)\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">特点</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"trait\" value=\"{{ data.trait }}\" placeholder=\"请输入特点（以英文逗号分隔）例如：AAA,BBB,CCC\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">面积</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"area\" value=\"{{ data.area }}\" placeholder=\"请输入面积\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">地址</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"address\" value=\"{{ data.address }}\" placeholder=\"请输入地址\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">备注</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"remark\" value=\"{{ data.remark }}\" placeholder=\"请输入需要备注的信息\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">户型</label>
            <div class=\"col-sm-10\">
            {% for k,v in htype %}
              <label class=\"checkbox-inline\">
                {% if  v in data.htype %}
                  <input type=\"checkbox\" id=\"htype\" checked name=\"htype[]\" value=\"{{ v }}\"> {{ v }}
                {% else %}
                  <input type=\"checkbox\" id=\"htype\" name=\"htype[]\" value=\"{{ v }}\"> {{ v }}
                {% endif %}
              </label>
            {% endfor %}
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">产权类型</label>
            <div class=\"col-sm-10\">
            {% for k,v in prtype %}
              <label class=\"radio-inline\">
                {% if data.prtype == k and data.prtype is defined %}
                  <input type=\"radio\" name=\"prtype\" checked value=\"{{ k }}\"> {{ v }}
                {% else %}
                <input type=\"radio\" name=\"prtype\" value=\"{{ k }}\"> {{ v }}
                {% endif %}
              </label>
            {% endfor %}
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">房屋类型</label>
            <div class=\"col-sm-10\">
            {% for k,v in house_type %}
              <label class=\"radio-inline\">
                {% if data.house_type == k and data.house_type is defined %}
                  <input type=\"radio\" checked name=\"house_type\" value=\"{{ k }}\"> {{ v }}
                {% else %}
                  <input type=\"radio\"  name=\"house_type\" value=\"{{ k }}\"> {{ v }}
                {% endif %}
              </label>
            {% endfor %}
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">物业类型</label>
            <div class=\"col-sm-10\">
            {% for k,v in ptype %}
              <label class=\"checkbox-inline\">
                {% if v in data.ptype %}
                  <input type=\"checkbox\" id=\"ptype\" checked name=\"ptype[]\" value=\"{{ v }}\"> {{ v }}
                {% else %}
                <input type=\"checkbox\" id=\"ptype\" name=\"ptype[]\" value=\"{{ v }}\"> {{ v }}
                {% endif %}
              </label>
            {% endfor %}
            </div>
          </div>
          <div class=\"form-group\">
            <div class=\"col-sm-offset-2 col-sm-10\">
              <button type=\"submit\" class=\"btn btn-success\">下一步</button>
            </div>
          </div>
        </form>

      </div>
    </div>
  </div>
</div>
<!-- End Page -->
{% endblock %}
{% block js %}
<script src=\"/public/webuploader-0.1.5/dist/webuploader.js\"></script>
<script type=\"text/javascript\" src=\"/public/webuploader-0.1.5/examples/image-upload/upload.js\"></script>
<script src=\"/apps/admin/views/newHouseCatalog/js/add.js\"></script>
{% endblock %}", "newHouseCatalog/add.html", "/home/wwwroot/dev.tefangw.vag/wwwroot/apps/admin/views/newHouseCatalog/add.html");
    }
}
