<?php

/* usedHouseInfo/add.html */
class __TwigTemplate_642ff6fb930d5e60d1c5ddc4880fca4b414ed81e3006e89739a2df196aef4812 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.html", "usedHouseInfo/add.html", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
            'js' => array($this, 'block_js'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "
";
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "<!-- Page -->
<div class=\"page animsition\">
    <div class=\"page-header\">
        <h1 class=\"page-title\"># 房屋管理</h1>
    </div>
    <div class=\"page-content\">
        <div class=\"panel\">
            <div class=\"panel-heading\">
                <h3 class=\"panel-title\">@ 添加二手房详细</h3>
            </div>
               <div style=\"margin-bottom: 15px;\">
                   <form action=\"/admin/usedHouseInfo/add/uhcid/";
        // line 17
        echo twig_escape_filter($this->env, ($context["uhcid"] ?? null), "html", null, true);
        echo "\" method=\"post\">
                      <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
                        <input type=\"text\" class=\"form-control\" name=\"cname\" placeholder=\"请输入置业顾问姓名\">
                        <span class=\"input-group-btn\">
                          <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
                        </span>
                      </div>
                      <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
                        <input type=\"text\" class=\"form-control\" name=\"belong_company\" placeholder=\"请输入所属地产公司\">
                        <span class=\"input-group-btn\">
                          <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
                        </span>
                      </div>
                   </form>
               </div>
            <div class=\"panel-body\">
                <form class=\"form-horizontal\" id=\"usedHouseInfoForm\" action=\"/admin/usedHouseInfo/add/uhcid/";
        // line 33
        echo twig_escape_filter($this->env, ($context["uhcid"] ?? null), "html", null, true);
        echo "\" method=\"post\">
                    <input type=\"hidden\" name=\"uhcid\" value=\"";
        // line 34
        echo twig_escape_filter($this->env, ($context["uhcid"] ?? null), "html", null, true);
        echo "\">
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">选择置业顾问</label>
                        <div class=\"col-sm-10\">
                            <select multiple class=\"form-control\" name=\"pcid\" style=\"height: 300px;\">
                                ";
        // line 39
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["pcData"] ?? null));
        foreach ($context['_seq'] as $context["k"] => $context["v"]) {
            // line 40
            echo "                                ";
            if (($context["k"] == 0)) {
                // line 41
                echo "                                <option value=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                echo "\" selected=\"selected\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "cname", array()), "html", null, true);
                echo " # ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "phone", array()), "html", null, true);
                echo " # ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "belong_company", array()), "html", null, true);
                echo "</option>
                                ";
            } else {
                // line 43
                echo "                                <option value=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "cname", array()), "html", null, true);
                echo " # ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "phone", array()), "html", null, true);
                echo " # ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "belong_company", array()), "html", null, true);
                echo "</option>
                                ";
            }
            // line 45
            echo "                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['k'], $context['v'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 46
        echo "                            </select>
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">楼层</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" class=\"form-control\" name=\"tage\" value=\"";
        // line 52
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "tage", array()), "html", null, true);
        echo "\" placeholder=\"请输入楼层\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">单价</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" class=\"form-control\" name=\"unit_price\" value=\"";
        // line 58
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "unit_price", array()), "html", null, true);
        echo "\" placeholder=\"请输入单价\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">朝向</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" class=\"form-control\" name=\"orientation\" value=\"";
        // line 64
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "orientation", array()), "html", null, true);
        echo "\" placeholder=\"请输入朝向\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">类型</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" class=\"form-control\" name=\"type\" value=\"";
        // line 70
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "type", array()), "html", null, true);
        echo "\" placeholder=\"请输入类型\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">装修</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" class=\"form-control\" name=\"upfitter\" value=\"";
        // line 76
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "upfitter", array()), "html", null, true);
        echo "\" placeholder=\"装修\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">年代</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" class=\"form-control\" name=\"era\" value=\"";
        // line 82
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "era", array()), "html", null, true);
        echo "\" placeholder=\"输入年代\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">小区</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" class=\"form-control\" name=\"community\" value=\"";
        // line 88
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "community", array()), "html", null, true);
        echo "\" placeholder=\"输入小区\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">轨交</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" class=\"form-control\" name=\"rail_transit\" value=\"";
        // line 94
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "rail_transit", array()), "html", null, true);
        echo "\" placeholder=\"输入轨交,以英文逗号隔开\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputEmail3\" class=\"col-sm-2 control-label\">核心卖点</label>
                        <div class=\"col-sm-10\">
                            <script id=\"container\" name=\"selling_points\" type=\"text/plain\" style=\"height: 300px;\">";
        // line 100
        echo twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "selling_points", array());
        echo "</script>
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"col-sm-offset-2 col-sm-10\">
                            <button type=\"submit\" class=\"btn btn-success\">添加信息</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- End Page -->
";
    }

    // line 115
    public function block_js($context, array $blocks = array())
    {
        // line 116
        echo "<script src=\"/apps/admin/views/usedHouseInfo/js/add.js\"></script>
<script src=\"/public/ueditor/ueditor.config.js\"></script>
<script src=\"/public/ueditor/ueditor.all.js\"></script>
<script>
    var ue = UE.getEditor('container');
</script>
";
    }

    public function getTemplateName()
    {
        return "usedHouseInfo/add.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  224 => 116,  221 => 115,  202 => 100,  193 => 94,  184 => 88,  175 => 82,  166 => 76,  157 => 70,  148 => 64,  139 => 58,  130 => 52,  122 => 46,  116 => 45,  104 => 43,  92 => 41,  89 => 40,  85 => 39,  77 => 34,  73 => 33,  54 => 17,  41 => 6,  38 => 5,  33 => 3,  30 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layouts.html\" %}
{% block css %}

{% endblock %}
{% block content %}
<!-- Page -->
<div class=\"page animsition\">
    <div class=\"page-header\">
        <h1 class=\"page-title\"># 房屋管理</h1>
    </div>
    <div class=\"page-content\">
        <div class=\"panel\">
            <div class=\"panel-heading\">
                <h3 class=\"panel-title\">@ 添加二手房详细</h3>
            </div>
               <div style=\"margin-bottom: 15px;\">
                   <form action=\"/admin/usedHouseInfo/add/uhcid/{{ uhcid }}\" method=\"post\">
                      <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
                        <input type=\"text\" class=\"form-control\" name=\"cname\" placeholder=\"请输入置业顾问姓名\">
                        <span class=\"input-group-btn\">
                          <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
                        </span>
                      </div>
                      <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
                        <input type=\"text\" class=\"form-control\" name=\"belong_company\" placeholder=\"请输入所属地产公司\">
                        <span class=\"input-group-btn\">
                          <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
                        </span>
                      </div>
                   </form>
               </div>
            <div class=\"panel-body\">
                <form class=\"form-horizontal\" id=\"usedHouseInfoForm\" action=\"/admin/usedHouseInfo/add/uhcid/{{ uhcid }}\" method=\"post\">
                    <input type=\"hidden\" name=\"uhcid\" value=\"{{ uhcid }}\">
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">选择置业顾问</label>
                        <div class=\"col-sm-10\">
                            <select multiple class=\"form-control\" name=\"pcid\" style=\"height: 300px;\">
                                {% for k,v in pcData %}
                                {% if k == 0 %}
                                <option value=\"{{ v.id }}\" selected=\"selected\">{{ v.cname }} # {{ v.phone }} # {{ v.belong_company }}</option>
                                {% else %}
                                <option value=\"{{ v.id }}\">{{ v.cname }} # {{ v.phone }} # {{ v.belong_company }}</option>
                                {% endif %}
                                {% endfor %}
                            </select>
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">楼层</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" class=\"form-control\" name=\"tage\" value=\"{{ data.tage }}\" placeholder=\"请输入楼层\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">单价</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" class=\"form-control\" name=\"unit_price\" value=\"{{ data.unit_price }}\" placeholder=\"请输入单价\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">朝向</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" class=\"form-control\" name=\"orientation\" value=\"{{ data.orientation }}\" placeholder=\"请输入朝向\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">类型</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" class=\"form-control\" name=\"type\" value=\"{{ data.type }}\" placeholder=\"请输入类型\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">装修</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" class=\"form-control\" name=\"upfitter\" value=\"{{ data.upfitter }}\" placeholder=\"装修\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">年代</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" class=\"form-control\" name=\"era\" value=\"{{ data.era }}\" placeholder=\"输入年代\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">小区</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" class=\"form-control\" name=\"community\" value=\"{{ data.community }}\" placeholder=\"输入小区\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">轨交</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" class=\"form-control\" name=\"rail_transit\" value=\"{{ data.rail_transit }}\" placeholder=\"输入轨交,以英文逗号隔开\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputEmail3\" class=\"col-sm-2 control-label\">核心卖点</label>
                        <div class=\"col-sm-10\">
                            <script id=\"container\" name=\"selling_points\" type=\"text/plain\" style=\"height: 300px;\">{% autoescape false %}{{ data.selling_points }}{% endautoescape %}</script>
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"col-sm-offset-2 col-sm-10\">
                            <button type=\"submit\" class=\"btn btn-success\">添加信息</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- End Page -->
{% endblock %}
{% block js %}
<script src=\"/apps/admin/views/usedHouseInfo/js/add.js\"></script>
<script src=\"/public/ueditor/ueditor.config.js\"></script>
<script src=\"/public/ueditor/ueditor.all.js\"></script>
<script>
    var ue = UE.getEditor('container');
</script>
{% endblock %}", "usedHouseInfo/add.html", "/home/wwwroot/dev.tefangw.vag/wwwroot/apps/admin/views/usedHouseInfo/add.html");
    }
}
