<?php

/* viewNewHouse/house_info.html */
class __TwigTemplate_f314803edbe89e2bd8a5450ef0c1738d6c2dc09aa9897bdb8a770d87d0505462 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.html", "viewNewHouse/house_info.html", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
            'js' => array($this, 'block_js'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
    }

    // line 4
    public function block_content($context, array $blocks = array())
    {
        // line 5
        echo "<!-- Page -->
<div class=\"page animsition\">
  <div class=\"page-header\">
    <h1 class=\"page-title\"># 房屋审核</h1>
  </div>
  <div class=\"page-content\">
    <div class=\"panel\">
      <div class=\"panel-heading\">
        <h3 class=\"panel-title\">@ （";
        // line 13
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["title"] ?? null), "title", array()), "html", null, true);
        echo "）新房详细信息</h3>
      </div>
      <div class=\"panel-body\">
        ";
        // line 16
        if ((($context["title"] ?? null) == "")) {
            // line 17
            echo "        没有添加数据
        ";
        } else {
            // line 19
            echo "        <ul class=\"list-group list-group-bordered\">
        <li class=\"list-group-item\"><h4>详细信息</h4></li>
        <li class=\"list-group-item\">=
        <table style=\"font-size: 20px;\">
          <br><tr>小　　区:：</tr><tr>";
            // line 23
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["title"] ?? null), "community", array()), "html", null, true);
            echo "</tr></br>
          <br><tr>价　　格:：</tr><tr>";
            // line 24
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["title"] ?? null), "price", array()), "html", null, true);
            echo "</tr></br>
          <br><tr>展示价格:：</tr><tr>";
            // line 25
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["title"] ?? null), "show_price", array()), "html", null, true);
            echo "</tr></br>
          <br><tr>特　　点:：</tr><tr>";
            // line 26
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["title"] ?? null), "trait", array()), "html", null, true);
            echo "</tr></br>
          <br><tr>户　　型:：</tr><tr>";
            // line 27
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["title"] ?? null), "htype", array()), "html", null, true);
            echo "</tr></br>
          <br><tr>产权类型:：</tr><tr>";
            // line 28
            echo twig_escape_filter($this->env, ($context["prtype"] ?? null), "html", null, true);
            echo "</tr></br>
          <br><tr>面　　积:：</tr><tr>";
            // line 29
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["title"] ?? null), "area", array()), "html", null, true);
            echo "m²</tr></br>
          <br><tr>房屋类型:：</tr><tr>";
            // line 30
            echo twig_escape_filter($this->env, ($context["house_type"] ?? null), "html", null, true);
            echo "</tr></br>
          <br><tr>物业类型:：</tr><tr>";
            // line 31
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["title"] ?? null), "ptype", array()), "html", null, true);
            echo "</tr></br>
          <br><tr>地　　址:：</tr><tr>";
            // line 32
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["title"] ?? null), "address", array()), "html", null, true);
            echo "</tr></br>
          <br><tr>时　　间:：</tr><tr>";
            // line 33
            echo twig_escape_filter($this->env, ($context["ctime"] ?? null), "html", null, true);
            echo "</tr></br>
          <br><tr>备　　注:：</tr><tr>";
            // line 34
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["title"] ?? null), "remark", array()), "html", null, true);
            echo "</tr></br>
        </table>
        </li>
        ";
            // line 37
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "k", array()));
            foreach ($context['_seq'] as $context["k"] => $context["v"]) {
                // line 38
                echo "          <li class=\"list-group-item\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "k", array()), $context["k"], array(), "array"), "html", null, true);
                echo " : ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "v", array()), $context["k"], array(), "array"), "html", null, true);
                echo "</li>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['k'], $context['v'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 40
            echo "        <li class=\"list-group-item\"><h4>置业顾问</h4></li>
        <li class=\"list-group-item\">
          <img src=\"";
            // line 42
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["pcInfo"] ?? null), "head_portrait", array()), "html", null, true);
            echo "\" class=\"img-responsive\" style=\"width: 90px; height: 90px;\">
          <div style=\"font-size: 20px;\">";
            // line 43
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["pcInfo"] ?? null), "cname", array()), "html", null, true);
            echo ":(";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["pcInfo"] ?? null), "belong_company", array()), "html", null, true);
            echo ")</div>
          <div style=\"font-size: 20px;\">";
            // line 44
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["pcInfo"] ?? null), "phone", array()), "html", null, true);
            echo "</div>
          <a href=\"/admin/viewNewHouse/index\"><button class=\"btn btn-success\">返回</button></a>
        </li>
        </ul>
        ";
        }
        // line 49
        echo "      </div>
    </div>
  </div>
</div>
<!-- End Page -->
";
    }

    // line 55
    public function block_js($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "viewNewHouse/house_info.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  162 => 55,  153 => 49,  145 => 44,  139 => 43,  135 => 42,  131 => 40,  120 => 38,  116 => 37,  110 => 34,  106 => 33,  102 => 32,  98 => 31,  94 => 30,  90 => 29,  86 => 28,  82 => 27,  78 => 26,  74 => 25,  70 => 24,  66 => 23,  60 => 19,  56 => 17,  54 => 16,  48 => 13,  38 => 5,  35 => 4,  30 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layouts.html\" %}
{% block css %}
{% endblock %}
{% block content %}
<!-- Page -->
<div class=\"page animsition\">
  <div class=\"page-header\">
    <h1 class=\"page-title\"># 房屋审核</h1>
  </div>
  <div class=\"page-content\">
    <div class=\"panel\">
      <div class=\"panel-heading\">
        <h3 class=\"panel-title\">@ （{{ title.title }}）新房详细信息</h3>
      </div>
      <div class=\"panel-body\">
        {% if title == '' %}
        没有添加数据
        {% else %}
        <ul class=\"list-group list-group-bordered\">
        <li class=\"list-group-item\"><h4>详细信息</h4></li>
        <li class=\"list-group-item\">=
        <table style=\"font-size: 20px;\">
          <br><tr>小　　区:：</tr><tr>{{ title.community}}</tr></br>
          <br><tr>价　　格:：</tr><tr>{{ title.price }}</tr></br>
          <br><tr>展示价格:：</tr><tr>{{ title.show_price }}</tr></br>
          <br><tr>特　　点:：</tr><tr>{{ title.trait }}</tr></br>
          <br><tr>户　　型:：</tr><tr>{{ title.htype }}</tr></br>
          <br><tr>产权类型:：</tr><tr>{{ prtype }}</tr></br>
          <br><tr>面　　积:：</tr><tr>{{ title.area }}m²</tr></br>
          <br><tr>房屋类型:：</tr><tr>{{ house_type }}</tr></br>
          <br><tr>物业类型:：</tr><tr>{{ title.ptype }}</tr></br>
          <br><tr>地　　址:：</tr><tr>{{ title.address }}</tr></br>
          <br><tr>时　　间:：</tr><tr>{{ ctime }}</tr></br>
          <br><tr>备　　注:：</tr><tr>{{ title.remark }}</tr></br>
        </table>
        </li>
        {% for k,v in data.k %}
          <li class=\"list-group-item\">{{ data.k[k] }} : {{ data.v[k] }}</li>
        {% endfor %}
        <li class=\"list-group-item\"><h4>置业顾问</h4></li>
        <li class=\"list-group-item\">
          <img src=\"{{ pcInfo.head_portrait }}\" class=\"img-responsive\" style=\"width: 90px; height: 90px;\">
          <div style=\"font-size: 20px;\">{{ pcInfo.cname }}:({{ pcInfo.belong_company }})</div>
          <div style=\"font-size: 20px;\">{{ pcInfo.phone }}</div>
          <a href=\"/admin/viewNewHouse/index\"><button class=\"btn btn-success\">返回</button></a>
        </li>
        </ul>
        {% endif %}
      </div>
    </div>
  </div>
</div>
<!-- End Page -->
{% endblock %}
{% block js %}
{% endblock %}", "viewNewHouse/house_info.html", "/home/wwwroot/dev.tefangw.vag/wwwroot/apps/admin/views/viewNewHouse/house_info.html");
    }
}
