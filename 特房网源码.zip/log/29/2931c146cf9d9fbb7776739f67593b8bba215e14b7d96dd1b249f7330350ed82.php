<?php

/* usedHouseCatalog/index.html */
class __TwigTemplate_42122cf6a70e2c5b5e1ce9745c6e211166c37a9522c25013a6e5119b9f089d05 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.html", "usedHouseCatalog/index.html", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
            'js' => array($this, 'block_js'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "
";
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "<!-- Page -->
<div class=\"page animsition\">
    <div class=\"page-header\">
        <h1 class=\"page-title\"># 房屋管理</h1>
    </div>
    <div class=\"page-content\">
        <div class=\"panel\">
            <div class=\"panel-heading\">
                <h3 class=\"panel-title\">@ 二手房条目列表</h3>
            </div>

            <form action=\"/admin/usedHouseCatalog/index/status/";
        // line 17
        echo twig_escape_filter($this->env, ($context["status"] ?? null), "html", null, true);
        echo "\" method=\"POST\">
            <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
          <input type=\"text\" class=\"form-control\" name=\"area\" placeholder=\"请输入面积\">
          <span class=\"input-group-btn\">
            <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
          </span>
        </div>
        <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
          <input type=\"text\" class=\"form-control\" name=\"show_price\" placeholder=\"请输入价格\">
          <span class=\"input-group-btn\">
            <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
          </span>
        </div>
         <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
          <input type=\"text\" class=\"form-control\" name=\"cid\" placeholder=\"请输入城市\">
          <span class=\"input-group-btn\">
            <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
          </span>
        </div>
            </form>
            <ul class=\"nav nav-pills\" style=\"margin-left: 25px;\">
                <li role=\"presentation\" ";
        // line 38
        if ((($context["status"] ?? null) == 0)) {
            echo "class=\"active\"";
        }
        echo "><a href=\"/admin/usedHouseCatalog/index/status/0\">默认</a></li>
                <li role=\"presentation\" ";
        // line 39
        if ((($context["status"] ?? null) == 1)) {
            echo "class=\"active\"";
        }
        echo "><a href=\"/admin/usedHouseCatalog/index/status/1\">待审核</a></li>
                <li role=\"presentation\" ";
        // line 40
        if ((($context["status"] ?? null) == 2)) {
            echo "class=\"active\"";
        }
        echo "><a href=\"/admin/usedHouseCatalog/index/status/2\">未通过</a></li>
                <li role=\"presentation\" ";
        // line 41
        if ((($context["status"] ?? null) == 3)) {
            echo "class=\"active\"";
        }
        echo "><a href=\"/admin/usedHouseCatalog/index/status/3\">已通过</a></li>
            </ul>
            <div class=\"panel-body\">
                <table class=\"table table-hover\">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>所属城市</th>
                        <th>标题</th>
                        <th>展示价格</th>
                        <th>特点</th>
                        <th>面积</th>
                        <th>时间</th>
                        <th>操作</th>
                    </tr>
                    </thead>
                    <tbody>
                    ";
        // line 58
        if (($context["data"] ?? null)) {
            // line 59
            echo "                    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["data"] ?? null));
            foreach ($context['_seq'] as $context["k"] => $context["v"]) {
                // line 60
                echo "                    <tr>
                        <td>
                            ";
                // line 62
                if ((($context["status"] ?? null) == 3)) {
                    // line 63
                    echo "                            ";
                    if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "type", array()) == 1)) {
                        // line 64
                        echo "                            <span class=\"text-danger\">{隐藏}</span>
                            ";
                    } else {
                        // line 66
                        echo "                            <span class=\"text-success\">{展示}</span>
                            ";
                    }
                    // line 68
                    echo "                            ";
                }
                // line 69
                echo "                        </td>
                        <td>";
                // line 70
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "cityname", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 71
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "title", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 72
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "show_price", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 73
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "trait", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 74
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "area", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 75
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "ctime", array()), "Y-m-d H:i"), "html", null, true);
                echo "</td>
                        <td>
            <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"nhInfo(";
                // line 77
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                echo ");\">详细信息</button>
               <!--  <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"nhmInfo(";
                // line 78
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                echo ");\">主力户型</button> -->
                ";
                // line 79
                if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "status", array()) == 0)) {
                    // line 80
                    echo "                <button type=\"button\" class=\"btn btn-default btn-xs\" onclick=\"commit_status(";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                    echo ");\">提交审核</button>
                ";
                } elseif ((twig_get_attribute($this->env, $this->getSourceContext(),                 // line 81
$context["v"], "status", array()) == 1)) {
                    // line 82
                    echo "               
                ";
                } elseif ((twig_get_attribute($this->env, $this->getSourceContext(),                 // line 83
$context["v"], "status", array()) == 2)) {
                    // line 84
                    echo "             
                ";
                } elseif ((twig_get_attribute($this->env, $this->getSourceContext(),                 // line 85
$context["v"], "status", array()) == 3)) {
                    // line 86
                    echo "               

                ";
                    // line 88
                    if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "type", array()) == 0)) {
                        // line 89
                        echo "                  <button type=\"button\" class=\"btn btn-danger btn-xs\" onclick=\"flag(";
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                        echo ",1);\">隐藏</button>
                ";
                    } else {
                        // line 91
                        echo "                  <button type=\"button\" class=\"btn btn-success btn-xs\" onclick=\"flag(";
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                        echo ",0);\">展示</button>
                ";
                    }
                    // line 93
                    echo "
                ";
                }
                // line 95
                echo "                ";
                if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "status", array()) == 0)) {
                    // line 96
                    echo "                <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"edit(";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                    echo ");\">修改</button>
                <button type=\"button\" class=\"btn btn-default btn-xs\" onclick=\"del_info(";
                    // line 97
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                    echo ");\">删除</button>
                ";
                }
                // line 99
                echo "                ";
                if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "status", array()) == 2)) {
                    // line 100
                    echo "                <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"edit(";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                    echo ");\">修改</button>
                <button type=\"button\" class=\"btn btn-default btn-xs\" onclick=\"del_info(";
                    // line 101
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                    echo ");\">删除</button>
                ";
                }
                // line 103
                echo "                        </td>
                    </tr>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['k'], $context['v'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 106
            echo "                    ";
        } else {
            // line 107
            echo "                    <tr>
                        <td colspan=\"4\">
                            <blockquote>
                                <p>暂无数据 :(</p>
                            </blockquote>
                        </td>
                    </tr>
                    ";
        }
        // line 115
        echo "                    </tbody>
                </table>
                <div style=\"float: right;\">
                    ";
        // line 119
        echo "                    ";
        echo ($context["page"] ?? null);
        echo "
                    ";
        // line 121
        echo "                </div>

            </div>
        </div>
    </div>
</div>
<!-- End Page -->
";
    }

    // line 130
    public function block_js($context, array $blocks = array())
    {
        // line 131
        echo "<script src=\"/apps/admin/views/usedHouseCatalog/js/index.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "usedHouseCatalog/index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  293 => 131,  290 => 130,  279 => 121,  274 => 119,  269 => 115,  259 => 107,  256 => 106,  248 => 103,  243 => 101,  238 => 100,  235 => 99,  230 => 97,  225 => 96,  222 => 95,  218 => 93,  212 => 91,  206 => 89,  204 => 88,  200 => 86,  198 => 85,  195 => 84,  193 => 83,  190 => 82,  188 => 81,  183 => 80,  181 => 79,  177 => 78,  173 => 77,  168 => 75,  164 => 74,  160 => 73,  156 => 72,  152 => 71,  148 => 70,  145 => 69,  142 => 68,  138 => 66,  134 => 64,  131 => 63,  129 => 62,  125 => 60,  120 => 59,  118 => 58,  96 => 41,  90 => 40,  84 => 39,  78 => 38,  54 => 17,  41 => 6,  38 => 5,  33 => 3,  30 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layouts.html\" %}
{% block css %}

{% endblock %}
{% block content %}
<!-- Page -->
<div class=\"page animsition\">
    <div class=\"page-header\">
        <h1 class=\"page-title\"># 房屋管理</h1>
    </div>
    <div class=\"page-content\">
        <div class=\"panel\">
            <div class=\"panel-heading\">
                <h3 class=\"panel-title\">@ 二手房条目列表</h3>
            </div>

            <form action=\"/admin/usedHouseCatalog/index/status/{{ status }}\" method=\"POST\">
            <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
          <input type=\"text\" class=\"form-control\" name=\"area\" placeholder=\"请输入面积\">
          <span class=\"input-group-btn\">
            <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
          </span>
        </div>
        <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
          <input type=\"text\" class=\"form-control\" name=\"show_price\" placeholder=\"请输入价格\">
          <span class=\"input-group-btn\">
            <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
          </span>
        </div>
         <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
          <input type=\"text\" class=\"form-control\" name=\"cid\" placeholder=\"请输入城市\">
          <span class=\"input-group-btn\">
            <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
          </span>
        </div>
            </form>
            <ul class=\"nav nav-pills\" style=\"margin-left: 25px;\">
                <li role=\"presentation\" {% if status == 0 %}class=\"active\"{% endif %}><a href=\"/admin/usedHouseCatalog/index/status/0\">默认</a></li>
                <li role=\"presentation\" {% if status == 1 %}class=\"active\"{% endif %}><a href=\"/admin/usedHouseCatalog/index/status/1\">待审核</a></li>
                <li role=\"presentation\" {% if status == 2 %}class=\"active\"{% endif %}><a href=\"/admin/usedHouseCatalog/index/status/2\">未通过</a></li>
                <li role=\"presentation\" {% if status == 3 %}class=\"active\"{% endif %}><a href=\"/admin/usedHouseCatalog/index/status/3\">已通过</a></li>
            </ul>
            <div class=\"panel-body\">
                <table class=\"table table-hover\">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>所属城市</th>
                        <th>标题</th>
                        <th>展示价格</th>
                        <th>特点</th>
                        <th>面积</th>
                        <th>时间</th>
                        <th>操作</th>
                    </tr>
                    </thead>
                    <tbody>
                    {% if data %}
                    {% for k,v in data %}
                    <tr>
                        <td>
                            {% if status == 3 %}
                            {% if v.type == 1 %}
                            <span class=\"text-danger\">{隐藏}</span>
                            {% else %}
                            <span class=\"text-success\">{展示}</span>
                            {% endif %}
                            {% endif %}
                        </td>
                        <td>{{ v.cityname }}</td>
                        <td>{{ v.title }}</td>
                        <td>{{ v.show_price }}</td>
                        <td>{{ v.trait }}</td>
                        <td>{{ v.area }}</td>
                        <td>{{ v.ctime|date(\"Y-m-d H:i\") }}</td>
                        <td>
            <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"nhInfo({{ v.id }});\">详细信息</button>
               <!--  <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"nhmInfo({{ v.id }});\">主力户型</button> -->
                {% if v.status == 0 %}
                <button type=\"button\" class=\"btn btn-default btn-xs\" onclick=\"commit_status({{ v.id }});\">提交审核</button>
                {% elseif v.status == 1 %}
               
                {% elseif v.status == 2 %}
             
                {% elseif v.status == 3 %}
               

                {% if v.type == 0 %}
                  <button type=\"button\" class=\"btn btn-danger btn-xs\" onclick=\"flag({{ v.id }},1);\">隐藏</button>
                {% else %}
                  <button type=\"button\" class=\"btn btn-success btn-xs\" onclick=\"flag({{ v.id }},0);\">展示</button>
                {% endif %}

                {% endif %}
                {% if v.status == 0 %}
                <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"edit({{ v.id }});\">修改</button>
                <button type=\"button\" class=\"btn btn-default btn-xs\" onclick=\"del_info({{ v.id }});\">删除</button>
                {% endif %}
                {% if v.status == 2 %}
                <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"edit({{ v.id }});\">修改</button>
                <button type=\"button\" class=\"btn btn-default btn-xs\" onclick=\"del_info({{ v.id }});\">删除</button>
                {% endif %}
                        </td>
                    </tr>
                    {% endfor %}
                    {% else %}
                    <tr>
                        <td colspan=\"4\">
                            <blockquote>
                                <p>暂无数据 :(</p>
                            </blockquote>
                        </td>
                    </tr>
                    {% endif %}
                    </tbody>
                </table>
                <div style=\"float: right;\">
                    {% autoescape false %}
                    {{ page }}
                    {% endautoescape %}
                </div>

            </div>
        </div>
    </div>
</div>
<!-- End Page -->
{% endblock %}

{% block js %}
<script src=\"/apps/admin/views/usedHouseCatalog/js/index.js\"></script>
{% endblock %}", "usedHouseCatalog/index.html", "/home/wwwroot/dev.tefangw.vag/wwwroot/apps/admin/views/usedHouseCatalog/index.html");
    }
}
