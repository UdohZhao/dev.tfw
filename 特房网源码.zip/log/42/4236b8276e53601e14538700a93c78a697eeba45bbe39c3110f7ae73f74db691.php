<?php

/* newHouseMain/index.html */
class __TwigTemplate_577f4346d86daa9dac71fca54c194d1d29e90b4072febebcbc6259bf7be30c77 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.html", "newHouseMain/index.html", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
            'js' => array($this, 'block_js'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "
";
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "<!-- Page -->
<div class=\"page animsition\">
  <div class=\"page-header\">
    <h1 class=\"page-title\"># 房屋管理</h1>
  </div>
  <div class=\"page-content\">
    <div class=\"panel\">
      <div class=\"panel-heading\">
        <h3 class=\"panel-title\">@ （";
        // line 14
        echo twig_escape_filter($this->env, ($context["tit"] ?? null), "html", null, true);
        echo "）新房主力户型</h3>
      </div>
      <div class=\"panel-body\">
        <table class=\"table table-hover\">
        <thead>
          <tr>
            <th>#</th>
            <th>封面图片</th>
            <th>户型</th>
            <th>名称</th>
            <th>特点</th>
            <th>价格</th>
            <th>建筑面积</th>
            ";
        // line 27
        if ((($context["status"] ?? null) == 0)) {
            // line 28
            echo "            <th>操作</th>
            ";
        }
        // line 30
        echo "            ";
        if ((($context["status"] ?? null) == 2)) {
            // line 31
            echo "            <th>操作</th>
            ";
        }
        // line 33
        echo "          </tr>
        </thead>
        <tbody>
        ";
        // line 36
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["data"] ?? null));
        foreach ($context['_seq'] as $context["k"] => $context["v"]) {
            // line 37
            echo "          <tr>
            <td></td>
            <td>
              <img src=\"";
            // line 40
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "cover_path", array()), "html", null, true);
            echo "\" class=\"img-responsive\" style=\"width: 90px; height: 90px;\">
            </td>
            <td>";
            // line 42
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "house_type_name", array()), "html", null, true);
            echo "</td>
            <td>";
            // line 43
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "cname", array()), "html", null, true);
            echo "</td>
            <td>";
            // line 44
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "trait", array()), "html", null, true);
            echo "</td>
            <td>";
            // line 45
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "price", array()), "html", null, true);
            echo "万/套</td>
            <td>";
            // line 46
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "covered_area", array()), "html", null, true);
            echo "㎡</td>
            <td>
            ";
            // line 48
            if ((($context["status"] ?? null) == 0)) {
                // line 49
                echo "              <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"edit(";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                echo ");\">修改</button>
              <button type=\"button\" class=\"btn btn-default btn-xs\" onclick=\"del(";
                // line 50
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                echo ");\">删除</button>
           ";
            }
            // line 52
            echo "           ";
            if ((($context["status"] ?? null) == 2)) {
                // line 53
                echo "              <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"edit(";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                echo ");\">修改</button>
              <button type=\"button\" class=\"btn btn-default btn-xs\" onclick=\"del(";
                // line 54
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                echo ");\">删除</button>
           ";
            }
            // line 56
            echo "            </td>
          </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['k'], $context['v'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 59
        echo "        </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<!-- End Page -->
";
    }

    // line 67
    public function block_js($context, array $blocks = array())
    {
        // line 68
        echo "<script src=\"/apps/admin/views/newHouseMain/js/index.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "newHouseMain/index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  167 => 68,  164 => 67,  153 => 59,  145 => 56,  140 => 54,  135 => 53,  132 => 52,  127 => 50,  122 => 49,  120 => 48,  115 => 46,  111 => 45,  107 => 44,  103 => 43,  99 => 42,  94 => 40,  89 => 37,  85 => 36,  80 => 33,  76 => 31,  73 => 30,  69 => 28,  67 => 27,  51 => 14,  41 => 6,  38 => 5,  33 => 3,  30 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layouts.html\" %}
{% block css %}

{% endblock %}
{% block content %}
<!-- Page -->
<div class=\"page animsition\">
  <div class=\"page-header\">
    <h1 class=\"page-title\"># 房屋管理</h1>
  </div>
  <div class=\"page-content\">
    <div class=\"panel\">
      <div class=\"panel-heading\">
        <h3 class=\"panel-title\">@ （{{ tit }}）新房主力户型</h3>
      </div>
      <div class=\"panel-body\">
        <table class=\"table table-hover\">
        <thead>
          <tr>
            <th>#</th>
            <th>封面图片</th>
            <th>户型</th>
            <th>名称</th>
            <th>特点</th>
            <th>价格</th>
            <th>建筑面积</th>
            {% if status == 0  %}
            <th>操作</th>
            {% endif %}
            {% if status == 2  %}
            <th>操作</th>
            {% endif %}
          </tr>
        </thead>
        <tbody>
        {% for k,v in data %}
          <tr>
            <td></td>
            <td>
              <img src=\"{{ v.cover_path }}\" class=\"img-responsive\" style=\"width: 90px; height: 90px;\">
            </td>
            <td>{{ v.house_type_name }}</td>
            <td>{{ v.cname }}</td>
            <td>{{ v.trait }}</td>
            <td>{{ v.price }}万/套</td>
            <td>{{ v.covered_area }}㎡</td>
            <td>
            {% if status == 0 %}
              <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"edit({{ v.id }});\">修改</button>
              <button type=\"button\" class=\"btn btn-default btn-xs\" onclick=\"del({{ v.id }});\">删除</button>
           {% endif %}
           {% if status == 2 %}
              <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"edit({{ v.id }});\">修改</button>
              <button type=\"button\" class=\"btn btn-default btn-xs\" onclick=\"del({{ v.id }});\">删除</button>
           {% endif %}
            </td>
          </tr>
        {% endfor %}
        </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<!-- End Page -->
{% endblock %}
{% block js %}
<script src=\"/apps/admin/views/newHouseMain/js/index.js\"></script>
{% endblock %}", "newHouseMain/index.html", "/home/wwwroot/dev.tefangw.vag/wwwroot/apps/admin/views/newHouseMain/index.html");
    }
}
