<?php

/* newHouseInfo/index.html */
class __TwigTemplate_8d97690759e3b4cf25a826214fa11f15dba02bf548d1e0697926360f9863e20f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.html", "newHouseInfo/index.html", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
            'js' => array($this, 'block_js'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
    }

    // line 4
    public function block_content($context, array $blocks = array())
    {
        // line 5
        echo "<!-- Page -->
<div class=\"page animsition\">
  <div class=\"page-header\">
    <h1 class=\"page-title\"># 房屋管理</h1>
  </div>
  <div class=\"page-content\">
    <div class=\"panel\">
      <div class=\"panel-heading\">
        <h3 class=\"panel-title\">@ 新房详细信息 -> ";
        // line 13
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "nhcData", array()), "title", array()), "html", null, true);
        echo "</h3>
      </div>
      <div class=\"panel-body\">
        ";
        // line 16
        if (($context["data"] ?? null)) {
            // line 17
            echo "          <blockquote>
            <p>* 基本信息</p>
          </blockquote>
          <blockquote>
            <p>小区：";
            // line 21
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "nhcData", array()), "community", array()), "html", null, true);
            echo "</p>
            <p>价格：¥";
            // line 22
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "nhcData", array()), "price", array()), "html", null, true);
            echo "</p>
            <p>展示价格：";
            // line 23
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "nhcData", array()), "show_price", array()), "html", null, true);
            echo "</p>
            <p>特点：";
            // line 24
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "nhcData", array()), "trait", array()), "html", null, true);
            echo "</p>
            <p>户型：";
            // line 25
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "nhcData", array()), "htype", array()), "html", null, true);
            echo "</p>
            <p>产权类型：";
            // line 26
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "nhcData", array()), "prtype", array()), "html", null, true);
            echo "</p>
            <p>面积：";
            // line 27
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "nhcData", array()), "area", array()), "html", null, true);
            echo "</p>
            <p>房屋类型：";
            // line 28
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "nhcData", array()), "house_type", array()), "html", null, true);
            echo "</p>
            <p>物业类型：";
            // line 29
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "nhcData", array()), "ptype", array()), "html", null, true);
            echo "</p>
            <p>地址：";
            // line 30
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "nhcData", array()), "address", array()), "html", null, true);
            echo "</p>
            <p>时间：";
            // line 31
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "nhcData", array()), "ctime", array()), "Y-m-d H:i"), "html", null, true);
            echo "</p>
            <p>备注：";
            // line 32
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "nhcData", array()), "remark", array()), "html", null, true);
            echo "</p>
          </blockquote>
          <blockquote>
            <p>* 详细信息</p>
          </blockquote>
          <blockquote>
            ";
            // line 38
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "nhiData", array()), "k", array()));
            foreach ($context['_seq'] as $context["k"] => $context["v"]) {
                // line 39
                echo "            <p>";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "nhiData", array()), "k", array()), $context["k"], array(), "array"), "html", null, true);
                echo " : ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "nhiData", array()), "v", array()), $context["k"], array(), "array"), "html", null, true);
                echo "</p>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['k'], $context['v'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 41
            echo "          </blockquote>
          <blockquote>
            <p>* 置业顾问</p>
          </blockquote>
          <blockquote>
            <p><img src=\"";
            // line 46
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "pcData", array()), "head_portrait", array()), "html", null, true);
            echo "\" style=\"width: 90px; height: 90px;\"></p>
            <p>姓名：";
            // line 47
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "pcData", array()), "cname", array()), "html", null, true);
            echo "</p>
            <p>所属地产公司：";
            // line 48
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "pcData", array()), "belong_company", array()), "html", null, true);
            echo "</p>
            <p>手机号码：";
            // line 49
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "pcData", array()), "phone", array()), "html", null, true);
            echo "</p>
          </blockquote>
        ";
        } else {
            // line 52
            echo "          <blockquote>
            <p>暂无数据</p>
          </blockquote>
        ";
        }
        // line 56
        echo "      </div>
    </div>
  </div>
</div>
<!-- End Page -->
";
    }

    // line 62
    public function block_js($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "newHouseInfo/index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  170 => 62,  161 => 56,  155 => 52,  149 => 49,  145 => 48,  141 => 47,  137 => 46,  130 => 41,  119 => 39,  115 => 38,  106 => 32,  102 => 31,  98 => 30,  94 => 29,  90 => 28,  86 => 27,  82 => 26,  78 => 25,  74 => 24,  70 => 23,  66 => 22,  62 => 21,  56 => 17,  54 => 16,  48 => 13,  38 => 5,  35 => 4,  30 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layouts.html\" %}
{% block css %}
{% endblock %}
{% block content %}
<!-- Page -->
<div class=\"page animsition\">
  <div class=\"page-header\">
    <h1 class=\"page-title\"># 房屋管理</h1>
  </div>
  <div class=\"page-content\">
    <div class=\"panel\">
      <div class=\"panel-heading\">
        <h3 class=\"panel-title\">@ 新房详细信息 -> {{data.nhcData.title}}</h3>
      </div>
      <div class=\"panel-body\">
        {% if data %}
          <blockquote>
            <p>* 基本信息</p>
          </blockquote>
          <blockquote>
            <p>小区：{{data.nhcData.community}}</p>
            <p>价格：¥{{data.nhcData.price}}</p>
            <p>展示价格：{{data.nhcData.show_price}}</p>
            <p>特点：{{data.nhcData.trait}}</p>
            <p>户型：{{data.nhcData.htype}}</p>
            <p>产权类型：{{data.nhcData.prtype}}</p>
            <p>面积：{{data.nhcData.area}}</p>
            <p>房屋类型：{{data.nhcData.house_type}}</p>
            <p>物业类型：{{data.nhcData.ptype}}</p>
            <p>地址：{{data.nhcData.address}}</p>
            <p>时间：{{data.nhcData.ctime|date('Y-m-d H:i')}}</p>
            <p>备注：{{data.nhcData.remark}}</p>
          </blockquote>
          <blockquote>
            <p>* 详细信息</p>
          </blockquote>
          <blockquote>
            {% for k,v in data.nhiData.k %}
            <p>{{data.nhiData.k[k]}} : {{data.nhiData.v[k]}}</p>
            {% endfor %}
          </blockquote>
          <blockquote>
            <p>* 置业顾问</p>
          </blockquote>
          <blockquote>
            <p><img src=\"{{data.pcData.head_portrait}}\" style=\"width: 90px; height: 90px;\"></p>
            <p>姓名：{{data.pcData.cname}}</p>
            <p>所属地产公司：{{data.pcData.belong_company}}</p>
            <p>手机号码：{{data.pcData.phone}}</p>
          </blockquote>
        {% else %}
          <blockquote>
            <p>暂无数据</p>
          </blockquote>
        {% endif %}
      </div>
    </div>
  </div>
</div>
<!-- End Page -->
{% endblock %}
{% block js %}
{% endblock %}", "newHouseInfo/index.html", "/home/wwwroot/dev.tefangw.vag/wwwroot/apps/admin/views/newHouseInfo/index.html");
    }
}
