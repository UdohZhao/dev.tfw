<?php

/* viewNewHouse/index.html */
class __TwigTemplate_9c6a4881af4b1d03eda542459b3369aec2e2c258520015f036ec9c44aae9e5bd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.html", "viewNewHouse/index.html", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
            'js' => array($this, 'block_js'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "
";
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "<!-- Page -->
<div class=\"page animsition\">
    <div class=\"page-header\">
        <h1 class=\"page-title\"># 房屋审核</h1>
    </div>
    <div class=\"page-content\">
        <div class=\"panel\">
            <div class=\"panel-heading\">
                <h3 class=\"panel-title\">@ 新房审核</h3>
            </div>
            <form action=\"/admin/viewNewHouse/index/status/";
        // line 16
        echo twig_escape_filter($this->env, ($context["status"] ?? null), "html", null, true);
        echo "\" method=\"post\">
                 <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
          <input type=\"text\" class=\"form-control\" name=\"area\" placeholder=\"请输入面积\">
          <span class=\"input-group-btn\">
            <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
          </span>
        </div>
        <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
          <input type=\"text\" class=\"form-control\" name=\"show_price\" placeholder=\"请输入价格\">
          <span class=\"input-group-btn\">
            <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
          </span>
        </div>
         <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
          <input type=\"text\" class=\"form-control\" name=\"cid\" placeholder=\"请输入城市\">
          <span class=\"input-group-btn\">
            <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
          </span>
        </div>
            </form>
            <ul class=\"nav nav-pills\" style=\"margin-left: 25px;\">
                <li role=\"presentation\" class=\"active\"><a href=\"/admin/viewNewHouse/index\">待审核</a></li>
            </ul>
            <div class=\"panel-body\">
                <table class=\"table table-hover\">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>所属城市</th>
                        <th>标题</th>
                        <th>展示价格</th>
                        <th>特点</th>
                        <th>面积</th>
                        <th>地址</th>
                        <th>时间</th>
                        <th>操作</th>
                    </tr>
                    </thead>
                    <tbody>
                    ";
        // line 55
        if (($context["data"] ?? null)) {
            // line 56
            echo "                    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["data"] ?? null));
            foreach ($context['_seq'] as $context["k"] => $context["v"]) {
                // line 57
                echo "                    <tr>
                        <td>
                            ";
                // line 59
                if ((($context["status"] ?? null) == 4)) {
                    // line 60
                    echo "                            ";
                    if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "type", array()) == 1)) {
                        // line 61
                        echo "                            <span class=\"text-danger\">{隐藏}</span>
                            ";
                    } else {
                        // line 63
                        echo "                            <span class=\"text-success\">{展示}</span>
                            ";
                    }
                    // line 65
                    echo "                            ";
                }
                // line 66
                echo "                        </td>
                        <td>";
                // line 67
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "cityname", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 68
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "title", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 69
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "show_price", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 70
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "trait", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 71
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "area", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 72
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "address", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 73
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "ctime", array()), "Y-m-d H:i"), "html", null, true);
                echo "</td>
                        <td>
                            <button type=\"button\" class=\"btn  btn-default btn-xs\" onclick=\"nhInfo(";
                // line 75
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                echo ");\" >详细信息</button>
                            <button type=\"button\" class=\"btn  btn-default btn-xs\" onclick=\"nhmInfo(";
                // line 76
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                echo ");\">主力户型</button> 
                            <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"detail_info(";
                // line 77
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                echo ");\" >进入审核</button>

                        </td>
                    </tr>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['k'], $context['v'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 82
            echo "                    ";
        } else {
            // line 83
            echo "                    <tr>
                        <td colspan=\"4\">
                            <blockquote>
                                <p>暂无数据 :(</p>
                            </blockquote>
                        </td>
                    </tr>
                    ";
        }
        // line 91
        echo "                    </tbody>
                </table>

                <div style=\"float: right;\">
                    ";
        // line 96
        echo "                    ";
        echo ($context["page"] ?? null);
        echo "
                    ";
        // line 98
        echo "                </div>

            </div>
        </div>
    </div>
</div>
<!-- End Page -->
";
    }

    // line 107
    public function block_js($context, array $blocks = array())
    {
        // line 108
        echo "<script src=\"/apps/admin/views/viewNewHouse/js/index.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "viewNewHouse/index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  211 => 108,  208 => 107,  197 => 98,  192 => 96,  186 => 91,  176 => 83,  173 => 82,  162 => 77,  158 => 76,  154 => 75,  149 => 73,  145 => 72,  141 => 71,  137 => 70,  133 => 69,  129 => 68,  125 => 67,  122 => 66,  119 => 65,  115 => 63,  111 => 61,  108 => 60,  106 => 59,  102 => 57,  97 => 56,  95 => 55,  53 => 16,  41 => 6,  38 => 5,  33 => 3,  30 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layouts.html\" %}
{% block css %}

{% endblock %}
{% block content %}
<!-- Page -->
<div class=\"page animsition\">
    <div class=\"page-header\">
        <h1 class=\"page-title\"># 房屋审核</h1>
    </div>
    <div class=\"page-content\">
        <div class=\"panel\">
            <div class=\"panel-heading\">
                <h3 class=\"panel-title\">@ 新房审核</h3>
            </div>
            <form action=\"/admin/viewNewHouse/index/status/{{ status }}\" method=\"post\">
                 <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
          <input type=\"text\" class=\"form-control\" name=\"area\" placeholder=\"请输入面积\">
          <span class=\"input-group-btn\">
            <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
          </span>
        </div>
        <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
          <input type=\"text\" class=\"form-control\" name=\"show_price\" placeholder=\"请输入价格\">
          <span class=\"input-group-btn\">
            <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
          </span>
        </div>
         <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
          <input type=\"text\" class=\"form-control\" name=\"cid\" placeholder=\"请输入城市\">
          <span class=\"input-group-btn\">
            <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
          </span>
        </div>
            </form>
            <ul class=\"nav nav-pills\" style=\"margin-left: 25px;\">
                <li role=\"presentation\" class=\"active\"><a href=\"/admin/viewNewHouse/index\">待审核</a></li>
            </ul>
            <div class=\"panel-body\">
                <table class=\"table table-hover\">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>所属城市</th>
                        <th>标题</th>
                        <th>展示价格</th>
                        <th>特点</th>
                        <th>面积</th>
                        <th>地址</th>
                        <th>时间</th>
                        <th>操作</th>
                    </tr>
                    </thead>
                    <tbody>
                    {% if data %}
                    {% for k,v in data %}
                    <tr>
                        <td>
                            {% if status == 4 %}
                            {% if v.type == 1 %}
                            <span class=\"text-danger\">{隐藏}</span>
                            {% else %}
                            <span class=\"text-success\">{展示}</span>
                            {% endif %}
                            {% endif %}
                        </td>
                        <td>{{ v.cityname }}</td>
                        <td>{{ v.title }}</td>
                        <td>{{ v.show_price }}</td>
                        <td>{{ v.trait }}</td>
                        <td>{{ v.area }}</td>
                        <td>{{ v.address }}</td>
                        <td>{{ v.ctime|date(\"Y-m-d H:i\") }}</td>
                        <td>
                            <button type=\"button\" class=\"btn  btn-default btn-xs\" onclick=\"nhInfo({{ v.id }});\" >详细信息</button>
                            <button type=\"button\" class=\"btn  btn-default btn-xs\" onclick=\"nhmInfo({{ v.id }});\">主力户型</button> 
                            <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"detail_info({{ v.id }});\" >进入审核</button>

                        </td>
                    </tr>
                    {% endfor %}
                    {% else %}
                    <tr>
                        <td colspan=\"4\">
                            <blockquote>
                                <p>暂无数据 :(</p>
                            </blockquote>
                        </td>
                    </tr>
                    {% endif %}
                    </tbody>
                </table>

                <div style=\"float: right;\">
                    {% autoescape false %}
                    {{ page }}
                    {% endautoescape %}
                </div>

            </div>
        </div>
    </div>
</div>
<!-- End Page -->
{% endblock %}

{% block js %}
<script src=\"/apps/admin/views/viewNewHouse/js/index.js\"></script>
{% endblock %}", "viewNewHouse/index.html", "/home/wwwroot/dev.tefangw.vag/wwwroot/apps/admin/views/viewNewHouse/index.html");
    }
}
