<?php

/* tenmentInfo/index.html */
class __TwigTemplate_a09de1bedebd043ad1afbf7193672621c0c2fa16dcc0089db865cfa03109ed69 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.html", "tenmentInfo/index.html", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
            'js' => array($this, 'block_js'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
    }

    // line 4
    public function block_content($context, array $blocks = array())
    {
        // line 5
        echo "<!-- Page -->
<div class=\"page animsition\">
  <div class=\"page-header\">
    <h1 class=\"page-title\"># 房屋管理</h1>
  </div>
  <div class=\"page-content\">
    <div class=\"panel\">
      <div class=\"panel-heading\">
        <h3 class=\"panel-title\">@ （";
        // line 13
        echo twig_escape_filter($this->env, ($context["title"] ?? null), "html", null, true);
        echo "）租房详细信息</h3>
      </div>
      <div class=\"panel-body\">
        ";
        // line 16
        if ((($context["data"] ?? null) == "")) {
            // line 17
            echo "        没有添加数据
        ";
        } else {
            // line 19
            echo "        <ul class=\"list-group list-group-bordered\">
        <li class=\"list-group-item\"><h4>详细信息</h4></li>
        <li class=\"list-group-item\">=
        <table style=\"font-size: 20px;\">
          <br><tr>面　　积:：</tr><tr>";
            // line 23
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "area", array()), "html", null, true);
            echo "m²</tr></br>
          <br><tr>朝　　向:：</tr><tr>";
            // line 24
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "orientation", array()), "html", null, true);
            echo "</tr></br>
          <br><tr>楼　　层:：</tr><tr>";
            // line 25
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "tage", array()), "html", null, true);
            echo "楼</tr></br>
          <br><tr>房屋类型:：</tr><tr>";
            // line 26
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "htype", array()), "html", null, true);
            echo "</tr></br>
          <br><tr>发布时间:：</tr><tr>";
            // line 27
            echo twig_escape_filter($this->env, ($context["ctime"] ?? null), "html", null, true);
            echo "</tr></br>
          <br><tr>房屋配置:：</tr><tr>";
            // line 28
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "hconfig", array()), "html", null, true);
            echo "</tr></br>
          <br><tr>房源概况:：</tr><tr>";
            // line 29
            echo twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "general_situation", array());
            echo "</tr></br>
        </table>
        </li>
        ";
            // line 32
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "k", array()));
            foreach ($context['_seq'] as $context["k"] => $context["v"]) {
                // line 33
                echo "          <li class=\"list-group-item\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "k", array()), $context["k"], array(), "array"), "html", null, true);
                echo " : ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "v", array()), $context["k"], array(), "array"), "html", null, true);
                echo "</li>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['k'], $context['v'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 35
            echo "        <li class=\"list-group-item\"><h4>置业顾问</h4></li>
        <li class=\"list-group-item\">
          <img src=\"";
            // line 37
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["pcInfo"] ?? null), "head_portrait", array()), "html", null, true);
            echo "\" class=\"img-responsive\" style=\"width: 90px; height: 90px;\">
          <div style=\"font-size: 20px;\">";
            // line 38
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["pcInfo"] ?? null), "cname", array()), "html", null, true);
            echo ":(";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["pcInfo"] ?? null), "belong_company", array()), "html", null, true);
            echo ")</div>
          <div style=\"font-size: 20px;\">";
            // line 39
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["pcInfo"] ?? null), "phone", array()), "html", null, true);
            echo "</div>
        </li>
        </ul>
        ";
        }
        // line 43
        echo "      </div>
    </div>
  </div>
</div>
<!-- End Page -->
";
    }

    // line 49
    public function block_js($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "tenmentInfo/index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  141 => 49,  132 => 43,  125 => 39,  119 => 38,  115 => 37,  111 => 35,  100 => 33,  96 => 32,  90 => 29,  86 => 28,  82 => 27,  78 => 26,  74 => 25,  70 => 24,  66 => 23,  60 => 19,  56 => 17,  54 => 16,  48 => 13,  38 => 5,  35 => 4,  30 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layouts.html\" %}
{% block css %}
{% endblock %}
{% block content %}
<!-- Page -->
<div class=\"page animsition\">
  <div class=\"page-header\">
    <h1 class=\"page-title\"># 房屋管理</h1>
  </div>
  <div class=\"page-content\">
    <div class=\"panel\">
      <div class=\"panel-heading\">
        <h3 class=\"panel-title\">@ （{{ title }}）租房详细信息</h3>
      </div>
      <div class=\"panel-body\">
        {% if data == '' %}
        没有添加数据
        {% else %}
        <ul class=\"list-group list-group-bordered\">
        <li class=\"list-group-item\"><h4>详细信息</h4></li>
        <li class=\"list-group-item\">=
        <table style=\"font-size: 20px;\">
          <br><tr>面　　积:：</tr><tr>{{ data.area}}m²</tr></br>
          <br><tr>朝　　向:：</tr><tr>{{ data.orientation }}</tr></br>
          <br><tr>楼　　层:：</tr><tr>{{ data.tage }}楼</tr></br>
          <br><tr>房屋类型:：</tr><tr>{{ data.htype }}</tr></br>
          <br><tr>发布时间:：</tr><tr>{{ ctime }}</tr></br>
          <br><tr>房屋配置:：</tr><tr>{{ data.hconfig }}</tr></br>
          <br><tr>房源概况:：</tr><tr>{% autoescape false %}{{ data.general_situation }}{% endautoescape %}</tr></br>
        </table>
        </li>
        {% for k,v in data.k %}
          <li class=\"list-group-item\">{{ data.k[k] }} : {{ data.v[k] }}</li>
        {% endfor %}
        <li class=\"list-group-item\"><h4>置业顾问</h4></li>
        <li class=\"list-group-item\">
          <img src=\"{{ pcInfo.head_portrait }}\" class=\"img-responsive\" style=\"width: 90px; height: 90px;\">
          <div style=\"font-size: 20px;\">{{ pcInfo.cname }}:({{ pcInfo.belong_company }})</div>
          <div style=\"font-size: 20px;\">{{ pcInfo.phone }}</div>
        </li>
        </ul>
        {% endif %}
      </div>
    </div>
  </div>
</div>
<!-- End Page -->
{% endblock %}
{% block js %}
{% endblock %}

", "tenmentInfo/index.html", "/home/wwwroot/dev.tefangw.vag/wwwroot/apps/admin/views/tenmentInfo/index.html");
    }
}
