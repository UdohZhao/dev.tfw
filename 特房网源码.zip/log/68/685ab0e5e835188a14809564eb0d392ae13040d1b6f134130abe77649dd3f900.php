<?php

/* index/index.html */
class __TwigTemplate_8aa436e1c5b0ea5a13ddfedf729c589e68ac216472df6e73a3e8d867ef0da1f2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.html", "index/index.html", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
            'js' => array($this, 'block_js'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "
";
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "<!-- Page -->
<div class=\"page animsition\">
  <div class=\"page-header\">
    <h1 class=\"page-title\"># 开发者信息</h1>
  </div>
  <div class=\"page-content\">
    <div class=\"panel\">
      <div class=\"panel-heading\">
        <h3 class=\"panel-title\"></h3>
      </div>
      <div class=\"panel-body\">
        <blockquote>
          <p>";
        // line 18
        echo twig_escape_filter($this->env, ($context["websiteName"] ?? null), "html", null, true);
        echo "</p>
        </blockquote>
        <blockquote>
          <p>开发团队：重庆存己科技</p>
        </blockquote>
        <blockquote>
          <p>技术维护：重庆存己科技</p>
        </blockquote>
        <blockquote>
          <p>联系人：赵先生</p>
        </blockquote>
        <blockquote>
          <p>联系电话：18423031898</p>
        </blockquote>
      </div>
    </div>
  </div>
</div>
<!-- End Page -->
";
    }

    // line 38
    public function block_js($context, array $blocks = array())
    {
        // line 39
        echo "
";
    }

    public function getTemplateName()
    {
        return "index/index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  82 => 39,  79 => 38,  55 => 18,  41 => 6,  38 => 5,  33 => 3,  30 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layouts.html\" %}
{% block css %}

{% endblock %}
{% block content %}
<!-- Page -->
<div class=\"page animsition\">
  <div class=\"page-header\">
    <h1 class=\"page-title\"># 开发者信息</h1>
  </div>
  <div class=\"page-content\">
    <div class=\"panel\">
      <div class=\"panel-heading\">
        <h3 class=\"panel-title\"></h3>
      </div>
      <div class=\"panel-body\">
        <blockquote>
          <p>{{ websiteName }}</p>
        </blockquote>
        <blockquote>
          <p>开发团队：重庆存己科技</p>
        </blockquote>
        <blockquote>
          <p>技术维护：重庆存己科技</p>
        </blockquote>
        <blockquote>
          <p>联系人：赵先生</p>
        </blockquote>
        <blockquote>
          <p>联系电话：18423031898</p>
        </blockquote>
      </div>
    </div>
  </div>
</div>
<!-- End Page -->
{% endblock %}
{% block js %}

{% endblock %}", "index/index.html", "/home/wwwroot/dev.tefangw.vag/wwwroot/apps/admin/views/index/index.html");
    }
}
