<?php

/* newHouseInfo/add.html */
class __TwigTemplate_f59bb1e3c18ec3864ff800072f4289f4b58a27753aefc9e5b72075e4f744de0d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.html", "newHouseInfo/add.html", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
            'js' => array($this, 'block_js'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "
";
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "<!-- Page -->
<div class=\"page animsition\">
  <div class=\"page-header\">
    <h1 class=\"page-title\"># 房屋管理</h1>
  </div>
  <div class=\"page-content\">
    <div class=\"panel\">
      <div class=\"panel-heading\">
        <h3 class=\"panel-title\"><!-- @ 添加新房详细 --></h3>
      </div>
      <div class=\"panel-body\">
       <form action=\"/admin/newHouseInfo/add/nhcid/";
        // line 17
        echo twig_escape_filter($this->env, ($context["nhcid"] ?? null), "html", null, true);
        echo "\" method=\"post\">
          <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
            <input type=\"text\" class=\"form-control\" name=\"cname\" placeholder=\"请输入置业顾问姓名\">
            <span class=\"input-group-btn\">
              <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
            </span>
          </div>
          <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
            <input type=\"text\" class=\"form-control\" name=\"belong_company\" placeholder=\"请输入所属地产公司\">
            <span class=\"input-group-btn\">
              <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
            </span>
          </div>
       </form>
      <form id=\"newHouseInfoForm\" action=\"/admin/newHouseInfo/add/nhcid/";
        // line 31
        echo twig_escape_filter($this->env, ($context["nhcid"] ?? null), "html", null, true);
        echo "\" method=\"post\">
        <div class=\"row\">
          <div class=\"col-md-12 form-group\">
            <h4>选择置业顾问：</h4>
            <select multiple class=\"form-control\" name=\"pcid\" style=\"height: 300px;\">
            ";
        // line 36
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["pcData"] ?? null));
        foreach ($context['_seq'] as $context["k"] => $context["v"]) {
            // line 37
            echo "              ";
            if (($context["k"] == 0)) {
                // line 38
                echo "                <option value=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                echo "\" selected=\"selected\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "cname", array()), "html", null, true);
                echo " # ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "phone", array()), "html", null, true);
                echo " # ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "belong_company", array()), "html", null, true);
                echo "</option>
              ";
            } else {
                // line 40
                echo "                <option value=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "cname", array()), "html", null, true);
                echo " # ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "phone", array()), "html", null, true);
                echo " # ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "belong_company", array()), "html", null, true);
                echo "</option>
              ";
            }
            // line 42
            echo "            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['k'], $context['v'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 43
        echo "            </select>
          </div>
        </div>
        <blockquote>
          <p>添加新房详细</p>
        </blockquote>
        <div class=\"row\" id=\"column\">
          <div class=\"col-md-6 form-group\">
            <input type=\"text\" class=\"form-control\" name=\"k[]\" placeholder=\"请输入键名\">
          </div>
          <div class=\"col-md-6 form-group\">
            <input type=\"text\" class=\"form-control\" name=\"v[]\" placeholder=\"请输入键值\">
          </div>
        </div>
        <button type=\"submit\" class=\"btn btn-success\">下一步</button>
      </form>
      <button type=\"button\" class=\"btn btn-danger btn-lg btn-block\" style=\"width: 20%;float: right;\" onclick=\"addColumn();\">+ 添加一栏</button>
      </div>
    </div>
  </div>
</div>
<!-- End Page -->
";
    }

    // line 66
    public function block_js($context, array $blocks = array())
    {
        // line 67
        echo "<script src=\"/apps/admin/views/newHouseInfo/js/add.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "newHouseInfo/add.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  145 => 67,  142 => 66,  116 => 43,  110 => 42,  98 => 40,  86 => 38,  83 => 37,  79 => 36,  71 => 31,  54 => 17,  41 => 6,  38 => 5,  33 => 3,  30 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layouts.html\" %}
{% block css %}

{% endblock %}
{% block content %}
<!-- Page -->
<div class=\"page animsition\">
  <div class=\"page-header\">
    <h1 class=\"page-title\"># 房屋管理</h1>
  </div>
  <div class=\"page-content\">
    <div class=\"panel\">
      <div class=\"panel-heading\">
        <h3 class=\"panel-title\"><!-- @ 添加新房详细 --></h3>
      </div>
      <div class=\"panel-body\">
       <form action=\"/admin/newHouseInfo/add/nhcid/{{ nhcid }}\" method=\"post\">
          <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
            <input type=\"text\" class=\"form-control\" name=\"cname\" placeholder=\"请输入置业顾问姓名\">
            <span class=\"input-group-btn\">
              <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
            </span>
          </div>
          <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
            <input type=\"text\" class=\"form-control\" name=\"belong_company\" placeholder=\"请输入所属地产公司\">
            <span class=\"input-group-btn\">
              <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
            </span>
          </div>
       </form>
      <form id=\"newHouseInfoForm\" action=\"/admin/newHouseInfo/add/nhcid/{{ nhcid }}\" method=\"post\">
        <div class=\"row\">
          <div class=\"col-md-12 form-group\">
            <h4>选择置业顾问：</h4>
            <select multiple class=\"form-control\" name=\"pcid\" style=\"height: 300px;\">
            {% for k,v in pcData %}
              {% if k == 0 %}
                <option value=\"{{ v.id }}\" selected=\"selected\">{{ v.cname }} # {{ v.phone }} # {{ v.belong_company }}</option>
              {% else %}
                <option value=\"{{ v.id }}\">{{ v.cname }} # {{ v.phone }} # {{ v.belong_company }}</option>
              {% endif %}
            {% endfor %}
            </select>
          </div>
        </div>
        <blockquote>
          <p>添加新房详细</p>
        </blockquote>
        <div class=\"row\" id=\"column\">
          <div class=\"col-md-6 form-group\">
            <input type=\"text\" class=\"form-control\" name=\"k[]\" placeholder=\"请输入键名\">
          </div>
          <div class=\"col-md-6 form-group\">
            <input type=\"text\" class=\"form-control\" name=\"v[]\" placeholder=\"请输入键值\">
          </div>
        </div>
        <button type=\"submit\" class=\"btn btn-success\">下一步</button>
      </form>
      <button type=\"button\" class=\"btn btn-danger btn-lg btn-block\" style=\"width: 20%;float: right;\" onclick=\"addColumn();\">+ 添加一栏</button>
      </div>
    </div>
  </div>
</div>
<!-- End Page -->
{% endblock %}
{% block js %}
<script src=\"/apps/admin/views/newHouseInfo/js/add.js\"></script>
{% endblock %}", "newHouseInfo/add.html", "/home/wwwroot/dev.tefangw.vag/wwwroot/apps/admin/views/newHouseInfo/add.html");
    }
}
