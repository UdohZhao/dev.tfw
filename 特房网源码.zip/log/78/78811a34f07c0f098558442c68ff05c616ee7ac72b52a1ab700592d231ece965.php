<?php

/* tenmentCatalog/index.html */
class __TwigTemplate_dfb3de409f09cf2c22c0b6c341a7ec50930cca151aea3e374b001251bebc0585 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.html", "tenmentCatalog/index.html", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
            'js' => array($this, 'block_js'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "
";
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "<!-- Page -->
<div class=\"page animsition\">
    <div class=\"page-header\">
        <h1 class=\"page-title\"># 房屋管理</h1>
    </div>
    <div class=\"page-content\">
        <div class=\"panel\">
            <div class=\"panel-heading\">
                <h3 class=\"panel-title\">@ 租房条目列表</h3>
            </div>

            <form action=\"/admin/tenmentCatalog/index/status/";
        // line 17
        echo twig_escape_filter($this->env, ($context["status"] ?? null), "html", null, true);
        echo "\" method=\"POST\">
                   <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
          <input type=\"text\" class=\"form-control\" name=\"area\" placeholder=\"请输入面积\">
          <span class=\"input-group-btn\">
            <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
          </span>
        </div>
        <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
          <input type=\"text\" class=\"form-control\" name=\"show_rent\" placeholder=\"请输入价格\">
          <span class=\"input-group-btn\">
            <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
          </span>
        </div>
        
         <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
          <input type=\"text\" class=\"form-control\" name=\"cid\" placeholder=\"请输入城市\">
          <span class=\"input-group-btn\">
            <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
          </span>
        </div>
            </form>
            <ul class=\"nav nav-pills\" style=\"margin-left: 25px;\">
                <li role=\"presentation\" ";
        // line 39
        if ((($context["status"] ?? null) == 0)) {
            echo "class=\"active\"";
        }
        echo "><a href=\"/admin/tenmentCatalog/index/status/0\">默认</a></li>
                <li role=\"presentation\" ";
        // line 40
        if ((($context["status"] ?? null) == 1)) {
            echo "class=\"active\"";
        }
        echo "><a href=\"/admin/tenmentCatalog/index/status/1\">待审核</a></li>
                <li role=\"presentation\" ";
        // line 41
        if ((($context["status"] ?? null) == 2)) {
            echo "class=\"active\"";
        }
        echo "><a href=\"/admin/tenmentCatalog/index/status/2\">未通过</a></li>
                <li role=\"presentation\" ";
        // line 42
        if ((($context["status"] ?? null) == 3)) {
            echo "class=\"active\"";
        }
        echo "><a href=\"/admin/tenmentCatalog/index/status/3\">已通过</a></li>
            </ul>
            <div class=\"panel-body\">
                <table class=\"table table-hover\">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>所属城市</th>
                        <th>标题</th>
                        <th>展示租金</th>
                        <th>装修类型</th>
                        <th>出租类型</th>
                        <th>时间</th>
                        <th>操作</th>
                    </tr>
                    </thead>
                    <tbody>
                    ";
        // line 59
        if (($context["data"] ?? null)) {
            // line 60
            echo "                    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["data"] ?? null));
            foreach ($context['_seq'] as $context["k"] => $context["v"]) {
                // line 61
                echo "                    <tr>
                        <td>
                            ";
                // line 63
                if ((($context["status"] ?? null) == 3)) {
                    // line 64
                    echo "                            ";
                    if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "type", array()) == 1)) {
                        // line 65
                        echo "                            <span class=\"text-danger\">{隐藏}</span>
                            ";
                    } else {
                        // line 67
                        echo "                            <span class=\"text-success\">{展示}</span>
                            ";
                    }
                    // line 69
                    echo "                            ";
                }
                // line 70
                echo "                        </td>
                        <td>";
                // line 71
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "cityname", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 72
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "title", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 73
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "show_rent", array()), "html", null, true);
                echo "</td>
                        <td>
                            ";
                // line 75
                if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "dtype", array()) == 0)) {
                    // line 76
                    echo "                            精装
                            ";
                } elseif ((twig_get_attribute($this->env, $this->getSourceContext(),                 // line 77
$context["v"], "dtype", array()) == 1)) {
                    // line 78
                    echo "                            中装
                            ";
                } else {
                    // line 80
                    echo "                            简装
                            ";
                }
                // line 82
                echo "                        </td>
                        <td>
                            ";
                // line 84
                if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "htype", array()) == 0)) {
                    // line 85
                    echo "                            整租
                            ";
                } else {
                    // line 87
                    echo "                            合租
                            ";
                }
                // line 89
                echo "                        </td>
                        <td>";
                // line 90
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "ctime", array()), "Y-m-d H:i"), "html", null, true);
                echo "</td>
                        <td>
            <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"nhInfo(";
                // line 92
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                echo ");\">详细信息</button>
                <!-- <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"nhmInfo(";
                // line 93
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                echo ");\">主力户型</button> -->
                ";
                // line 94
                if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "status", array()) == 0)) {
                    // line 95
                    echo "                <button type=\"button\" class=\"btn btn-default btn-xs\" onclick=\"commit_status(";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                    echo ");\">提交审核</button>
                ";
                } elseif ((twig_get_attribute($this->env, $this->getSourceContext(),                 // line 96
$context["v"], "status", array()) == 1)) {
                    // line 97
                    echo "               <!--  <button type=\"button\" class=\"btn btn-default btn-xs\" onclick=\"commit_adopt(";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                    echo ");\">可通过</button>
                 <button type=\"button\" class=\"btn btn-default btn-xs\" onclick=\"commit_pass(";
                    // line 98
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                    echo ");\">未通过</button> -->
                ";
                } elseif ((twig_get_attribute($this->env, $this->getSourceContext(),                 // line 99
$context["v"], "status", array()) == 2)) {
                    // line 100
                    echo "          
                ";
                } elseif ((twig_get_attribute($this->env, $this->getSourceContext(),                 // line 101
$context["v"], "status", array()) == 3)) {
                    // line 102
                    echo "          
                 ";
                    // line 103
                    if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "type", array()) == 0)) {
                        // line 104
                        echo "                  <button type=\"button\" class=\"btn btn-danger btn-xs\" onclick=\"flag(";
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                        echo ",1);\">隐藏</button>
                ";
                    } else {
                        // line 106
                        echo "                  <button type=\"button\" class=\"btn btn-success btn-xs\" onclick=\"flag(";
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                        echo ",0);\">展示</button>
                ";
                    }
                    // line 108
                    echo "                ";
                }
                // line 109
                echo "                ";
                if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "status", array()) == 0)) {
                    // line 110
                    echo "                <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"edit(";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                    echo ");\">修改</button>
                <button type=\"button\" class=\"btn btn-default btn-xs\" onclick=\"del_info(";
                    // line 111
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                    echo ");\">删除</button>
                ";
                }
                // line 113
                echo "                ";
                if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "status", array()) == 2)) {
                    // line 114
                    echo "                <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"edit(";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                    echo ");\">修改</button>
                <button type=\"button\" class=\"btn btn-default btn-xs\" onclick=\"del_info(";
                    // line 115
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                    echo ");\">删除</button>
                ";
                }
                // line 117
                echo "                        </td>
                    </tr>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['k'], $context['v'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 120
            echo "                    ";
        } else {
            // line 121
            echo "                    <tr>
                        <td colspan=\"4\">
                            <blockquote>
                                <p>暂无数据 :(</p>
                            </blockquote>
                        </td>
                    </tr>
                    ";
        }
        // line 129
        echo "                    </tbody>
                </table>
                <div style=\"float: right;\">
                    ";
        // line 133
        echo "                    ";
        echo ($context["page"] ?? null);
        echo "
                    ";
        // line 135
        echo "                </div>

            </div>
        </div>
    </div>
</div>
<!-- End Page -->
";
    }

    // line 144
    public function block_js($context, array $blocks = array())
    {
        // line 145
        echo "<script src=\"/apps/admin/views/tenmentCatalog/js/index.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "tenmentCatalog/index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  323 => 145,  320 => 144,  309 => 135,  304 => 133,  299 => 129,  289 => 121,  286 => 120,  278 => 117,  273 => 115,  268 => 114,  265 => 113,  260 => 111,  255 => 110,  252 => 109,  249 => 108,  243 => 106,  237 => 104,  235 => 103,  232 => 102,  230 => 101,  227 => 100,  225 => 99,  221 => 98,  216 => 97,  214 => 96,  209 => 95,  207 => 94,  203 => 93,  199 => 92,  194 => 90,  191 => 89,  187 => 87,  183 => 85,  181 => 84,  177 => 82,  173 => 80,  169 => 78,  167 => 77,  164 => 76,  162 => 75,  157 => 73,  153 => 72,  149 => 71,  146 => 70,  143 => 69,  139 => 67,  135 => 65,  132 => 64,  130 => 63,  126 => 61,  121 => 60,  119 => 59,  97 => 42,  91 => 41,  85 => 40,  79 => 39,  54 => 17,  41 => 6,  38 => 5,  33 => 3,  30 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layouts.html\" %}
{% block css %}

{% endblock %}
{% block content %}
<!-- Page -->
<div class=\"page animsition\">
    <div class=\"page-header\">
        <h1 class=\"page-title\"># 房屋管理</h1>
    </div>
    <div class=\"page-content\">
        <div class=\"panel\">
            <div class=\"panel-heading\">
                <h3 class=\"panel-title\">@ 租房条目列表</h3>
            </div>

            <form action=\"/admin/tenmentCatalog/index/status/{{ status }}\" method=\"POST\">
                   <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
          <input type=\"text\" class=\"form-control\" name=\"area\" placeholder=\"请输入面积\">
          <span class=\"input-group-btn\">
            <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
          </span>
        </div>
        <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
          <input type=\"text\" class=\"form-control\" name=\"show_rent\" placeholder=\"请输入价格\">
          <span class=\"input-group-btn\">
            <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
          </span>
        </div>
        
         <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
          <input type=\"text\" class=\"form-control\" name=\"cid\" placeholder=\"请输入城市\">
          <span class=\"input-group-btn\">
            <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
          </span>
        </div>
            </form>
            <ul class=\"nav nav-pills\" style=\"margin-left: 25px;\">
                <li role=\"presentation\" {% if status == 0 %}class=\"active\"{% endif %}><a href=\"/admin/tenmentCatalog/index/status/0\">默认</a></li>
                <li role=\"presentation\" {% if status == 1 %}class=\"active\"{% endif %}><a href=\"/admin/tenmentCatalog/index/status/1\">待审核</a></li>
                <li role=\"presentation\" {% if status == 2 %}class=\"active\"{% endif %}><a href=\"/admin/tenmentCatalog/index/status/2\">未通过</a></li>
                <li role=\"presentation\" {% if status == 3 %}class=\"active\"{% endif %}><a href=\"/admin/tenmentCatalog/index/status/3\">已通过</a></li>
            </ul>
            <div class=\"panel-body\">
                <table class=\"table table-hover\">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>所属城市</th>
                        <th>标题</th>
                        <th>展示租金</th>
                        <th>装修类型</th>
                        <th>出租类型</th>
                        <th>时间</th>
                        <th>操作</th>
                    </tr>
                    </thead>
                    <tbody>
                    {% if data %}
                    {% for k,v in data %}
                    <tr>
                        <td>
                            {% if status == 3 %}
                            {% if v.type == 1 %}
                            <span class=\"text-danger\">{隐藏}</span>
                            {% else %}
                            <span class=\"text-success\">{展示}</span>
                            {% endif %}
                            {% endif %}
                        </td>
                        <td>{{ v.cityname }}</td>
                        <td>{{ v.title }}</td>
                        <td>{{ v.show_rent }}</td>
                        <td>
                            {% if v.dtype == 0 %}
                            精装
                            {% elseif v.dtype == 1 %}
                            中装
                            {% else %}
                            简装
                            {% endif %}
                        </td>
                        <td>
                            {% if v.htype == 0 %}
                            整租
                            {% else %}
                            合租
                            {% endif %}
                        </td>
                        <td>{{ v.ctime|date(\"Y-m-d H:i\") }}</td>
                        <td>
            <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"nhInfo({{ v.id }});\">详细信息</button>
                <!-- <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"nhmInfo({{ v.id }});\">主力户型</button> -->
                {% if v.status == 0 %}
                <button type=\"button\" class=\"btn btn-default btn-xs\" onclick=\"commit_status({{ v.id }});\">提交审核</button>
                {% elseif v.status == 1 %}
               <!--  <button type=\"button\" class=\"btn btn-default btn-xs\" onclick=\"commit_adopt({{ v.id }});\">可通过</button>
                 <button type=\"button\" class=\"btn btn-default btn-xs\" onclick=\"commit_pass({{ v.id }});\">未通过</button> -->
                {% elseif v.status == 2 %}
          
                {% elseif v.status == 3 %}
          
                 {% if v.type == 0 %}
                  <button type=\"button\" class=\"btn btn-danger btn-xs\" onclick=\"flag({{ v.id }},1);\">隐藏</button>
                {% else %}
                  <button type=\"button\" class=\"btn btn-success btn-xs\" onclick=\"flag({{ v.id }},0);\">展示</button>
                {% endif %}
                {% endif %}
                {% if v.status == 0 %}
                <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"edit({{ v.id }});\">修改</button>
                <button type=\"button\" class=\"btn btn-default btn-xs\" onclick=\"del_info({{ v.id }});\">删除</button>
                {% endif %}
                {% if v.status == 2 %}
                <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"edit({{ v.id }});\">修改</button>
                <button type=\"button\" class=\"btn btn-default btn-xs\" onclick=\"del_info({{ v.id }});\">删除</button>
                {% endif %}
                        </td>
                    </tr>
                    {% endfor %}
                    {% else %}
                    <tr>
                        <td colspan=\"4\">
                            <blockquote>
                                <p>暂无数据 :(</p>
                            </blockquote>
                        </td>
                    </tr>
                    {% endif %}
                    </tbody>
                </table>
                <div style=\"float: right;\">
                    {% autoescape false %}
                    {{ page }}
                    {% endautoescape %}
                </div>

            </div>
        </div>
    </div>
</div>
<!-- End Page -->
{% endblock %}

{% block js %}
<script src=\"/apps/admin/views/tenmentCatalog/js/index.js\"></script>
{% endblock %}", "tenmentCatalog/index.html", "/home/wwwroot/dev.tefangw.vag/wwwroot/apps/admin/views/tenmentCatalog/index.html");
    }
}
