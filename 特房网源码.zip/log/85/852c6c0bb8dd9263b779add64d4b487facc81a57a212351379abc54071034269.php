<?php

/* viewNewHouse/houseDetail.html */
class __TwigTemplate_57c703ddc4a59439355b0b38f08bd3992226a2a65fee0c8195a0aba198d1759c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.html", "viewNewHouse/houseDetail.html", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
            'js' => array($this, 'block_js'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "<link rel=\"stylesheet\" href=\"/public/webuploader-0.1.5/dist/webuploader.css\">
<link rel=\"stylesheet\" type=\"text/css\" href=\"/public/webuploader-0.1.5/examples/image-upload/style.css\" />
";
    }

    // line 6
    public function block_content($context, array $blocks = array())
    {
        // line 7
        echo "<!-- Page -->
<div class=\"page animsition\">
    <div class=\"page-header\">
        <h1 class=\"page-title\"># 房屋审核</h1>
    </div>
    <div class=\"page-content\">
        <div class=\"panel\">
            <div class=\"panel-heading\">
                <h3 class=\"panel-title\">@ 新房审核</h3>
            </div>
            <div id=\"wrapper\">
                <div id=\"container\">
                    <!--头部，相册选择和格式选择-->
                    <div id=\"uploader\">
                        <div class=\"queueList\">

                             ";
        // line 23
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "slideshow", array()));
        foreach ($context['_seq'] as $context["k"] => $context["v"]) {
            // line 24
            echo "                                <img src=\"";
            echo twig_escape_filter($this->env, $context["v"], "html", null, true);
            echo "\" width=\"200\" height=\"200\"/>
                             ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['k'], $context['v'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 26
        echo "
                        </div>
                    </div>
                </div>
            </div>
            <div class=\"panel-body\">
                <form class=\"form-horizontal\" >
                    <div class=\"form-group\">
                        <label for=\"inputEmail3\" class=\"col-sm-2 control-label\">关联城市</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" class=\"form-control\" name=\"cid\" value=\"";
        // line 36
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "cid", array()), "html", null, true);
        echo "\" readonly=\"readonly\" placeholder=\"请输入城市名称\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">标题</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" class=\"form-control\" name=\"title\" value=\"";
        // line 42
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "title", array()), "html", null, true);
        echo "\"  readonly=\"readonly\" placeholder=\"请输入标题\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">小区</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\"  readonly=\"readonly\" class=\"form-control\" name=\"community\" value=\"";
        // line 48
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "community", array()), "html", null, true);
        echo "\" placeholder=\"请输入小区\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">价格</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" readonly=\"readonly\" class=\"form-control\" name=\"price\" value=\"";
        // line 54
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "price", array()), "html", null, true);
        echo "\" placeholder=\"请输入价格\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">展示价格</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" readonly=\"readonly\" class=\"form-control\" name=\"show_price\" value=\"";
        // line 60
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "show_price", array()), "html", null, true);
        echo "\" placeholder=\"请输入展示价格\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">特点</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" readonly=\"readonly\" class=\"form-control\" name=\"trait\" value=\"";
        // line 66
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "trait", array()), "html", null, true);
        echo "\" placeholder=\"请输入特点（以英文逗号分隔）例如：AAA,BBB,CCC\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">面积</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" readonly=\"readonly\" type=\"text\" class=\"form-control\" name=\"area\" value=\"";
        // line 72
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "area", array()), "html", null, true);
        echo "\" placeholder=\"请输入面积\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">地址</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" readonly=\"readonly\" class=\"form-control\" name=\"address\" value=\"";
        // line 78
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "address", array()), "html", null, true);
        echo "\" placeholder=\"请输入地址\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\"  class=\"col-sm-2 control-label\">户型</label>
                        <div class=\"col-sm-10\">
                            ";
        // line 84
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["htype"] ?? null));
        foreach ($context['_seq'] as $context["k"] => $context["v"]) {
            // line 85
            echo "                            <label class=\"checkbox-inline\">
                                ";
            // line 86
            if (twig_in_filter($context["v"], twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "htype", array()))) {
                // line 87
                echo "                                <input type=\"checkbox\" id=\"htype\" checked name=\"htype[]\" value=\"";
                echo twig_escape_filter($this->env, $context["v"], "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $context["v"], "html", null, true);
                echo "
                                ";
            } else {
                // line 89
                echo "                                <input type=\"checkbox\" id=\"htype\" name=\"htype[]\" value=\"";
                echo twig_escape_filter($this->env, $context["v"], "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $context["v"], "html", null, true);
                echo "
                                ";
            }
            // line 91
            echo "                            </label>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['k'], $context['v'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 93
        echo "                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">产权类型</label>
                        <div class=\"col-sm-10\">
                            ";
        // line 98
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["prtype"] ?? null));
        foreach ($context['_seq'] as $context["k"] => $context["v"]) {
            // line 99
            echo "                            <label class=\"radio-inline\">
                                ";
            // line 100
            if (((twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "prtype", array()) == $context["k"]) && twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "prtype", array(), "any", true, true))) {
                // line 101
                echo "                                <input type=\"radio\" name=\"prtype\" checked value=\"";
                echo twig_escape_filter($this->env, $context["k"], "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $context["v"], "html", null, true);
                echo "
                                ";
            } else {
                // line 103
                echo "                                <input type=\"radio\" name=\"prtype\" value=\"";
                echo twig_escape_filter($this->env, $context["k"], "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $context["v"], "html", null, true);
                echo "
                                ";
            }
            // line 105
            echo "                            </label>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['k'], $context['v'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 107
        echo "                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">房屋类型</label>
                        <div class=\"col-sm-10\">
                            ";
        // line 112
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["house_type"] ?? null));
        foreach ($context['_seq'] as $context["k"] => $context["v"]) {
            // line 113
            echo "                            <label class=\"radio-inline\">
                                ";
            // line 114
            if (((twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "house_type", array()) == $context["k"]) && twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "house_type", array(), "any", true, true))) {
                // line 115
                echo "                                <input type=\"radio\" checked name=\"house_type\" value=\"";
                echo twig_escape_filter($this->env, $context["k"], "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $context["v"], "html", null, true);
                echo "
                                ";
            } else {
                // line 117
                echo "                                <input type=\"radio\"  name=\"house_type\" value=\"";
                echo twig_escape_filter($this->env, $context["k"], "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $context["v"], "html", null, true);
                echo "
                                ";
            }
            // line 119
            echo "                            </label>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['k'], $context['v'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 121
        echo "                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">物业类型</label>
                        <div class=\"col-sm-10\">
                            ";
        // line 126
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["ptype"] ?? null));
        foreach ($context['_seq'] as $context["k"] => $context["v"]) {
            // line 127
            echo "                            <label class=\"checkbox-inline\">
                                ";
            // line 128
            if (twig_in_filter($context["v"], twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "ptype", array()))) {
                // line 129
                echo "                                <input type=\"checkbox\" id=\"ptype\" checked name=\"ptype[]\" value=\"";
                echo twig_escape_filter($this->env, $context["v"], "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $context["v"], "html", null, true);
                echo "
                                ";
            } else {
                // line 131
                echo "                                <input type=\"checkbox\" id=\"ptype\" name=\"ptype[]\" value=\"";
                echo twig_escape_filter($this->env, $context["v"], "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $context["v"], "html", null, true);
                echo "
                                ";
            }
            // line 133
            echo "                            </label>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['k'], $context['v'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 135
        echo "                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"col-sm-offset-2 col-sm-10\">
                            <input type=\"button\" onclick=\"check_info(3,'";
        // line 139
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "id", array()), "html", null, true);
        echo "')\" class=\"btn btn-success\" value=\"审核通过\"/>
                            <input type=\"button\" onclick=\"check_info(2,'";
        // line 140
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "id", array()), "html", null, true);
        echo "')\" class=\"btn btn-success\" value=\"拒绝通过\"/>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>
<!-- End Page -->
";
    }

    // line 151
    public function block_js($context, array $blocks = array())
    {
        // line 152
        echo "<script src=\"/apps/admin/views/viewNewHouse/js/houseDetail.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "viewNewHouse/houseDetail.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  334 => 152,  331 => 151,  316 => 140,  312 => 139,  306 => 135,  299 => 133,  291 => 131,  283 => 129,  281 => 128,  278 => 127,  274 => 126,  267 => 121,  260 => 119,  252 => 117,  244 => 115,  242 => 114,  239 => 113,  235 => 112,  228 => 107,  221 => 105,  213 => 103,  205 => 101,  203 => 100,  200 => 99,  196 => 98,  189 => 93,  182 => 91,  174 => 89,  166 => 87,  164 => 86,  161 => 85,  157 => 84,  148 => 78,  139 => 72,  130 => 66,  121 => 60,  112 => 54,  103 => 48,  94 => 42,  85 => 36,  73 => 26,  64 => 24,  60 => 23,  42 => 7,  39 => 6,  33 => 3,  30 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layouts.html\" %}
{% block css %}
<link rel=\"stylesheet\" href=\"/public/webuploader-0.1.5/dist/webuploader.css\">
<link rel=\"stylesheet\" type=\"text/css\" href=\"/public/webuploader-0.1.5/examples/image-upload/style.css\" />
{% endblock %}
{% block content %}
<!-- Page -->
<div class=\"page animsition\">
    <div class=\"page-header\">
        <h1 class=\"page-title\"># 房屋审核</h1>
    </div>
    <div class=\"page-content\">
        <div class=\"panel\">
            <div class=\"panel-heading\">
                <h3 class=\"panel-title\">@ 新房审核</h3>
            </div>
            <div id=\"wrapper\">
                <div id=\"container\">
                    <!--头部，相册选择和格式选择-->
                    <div id=\"uploader\">
                        <div class=\"queueList\">

                             {% for k,v in data.slideshow %}
                                <img src=\"{{ v }}\" width=\"200\" height=\"200\"/>
                             {% endfor %}

                        </div>
                    </div>
                </div>
            </div>
            <div class=\"panel-body\">
                <form class=\"form-horizontal\" >
                    <div class=\"form-group\">
                        <label for=\"inputEmail3\" class=\"col-sm-2 control-label\">关联城市</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" class=\"form-control\" name=\"cid\" value=\"{{ data.cid }}\" readonly=\"readonly\" placeholder=\"请输入城市名称\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">标题</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" class=\"form-control\" name=\"title\" value=\"{{ data.title }}\"  readonly=\"readonly\" placeholder=\"请输入标题\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">小区</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\"  readonly=\"readonly\" class=\"form-control\" name=\"community\" value=\"{{ data.community }}\" placeholder=\"请输入小区\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">价格</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" readonly=\"readonly\" class=\"form-control\" name=\"price\" value=\"{{ data.price }}\" placeholder=\"请输入价格\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">展示价格</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" readonly=\"readonly\" class=\"form-control\" name=\"show_price\" value=\"{{ data.show_price }}\" placeholder=\"请输入展示价格\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">特点</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" readonly=\"readonly\" class=\"form-control\" name=\"trait\" value=\"{{ data.trait }}\" placeholder=\"请输入特点（以英文逗号分隔）例如：AAA,BBB,CCC\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">面积</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" readonly=\"readonly\" type=\"text\" class=\"form-control\" name=\"area\" value=\"{{ data.area }}\" placeholder=\"请输入面积\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">地址</label>
                        <div class=\"col-sm-10\">
                            <input type=\"text\" readonly=\"readonly\" class=\"form-control\" name=\"address\" value=\"{{ data.address }}\" placeholder=\"请输入地址\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\"  class=\"col-sm-2 control-label\">户型</label>
                        <div class=\"col-sm-10\">
                            {% for k,v in htype %}
                            <label class=\"checkbox-inline\">
                                {% if  v in data.htype %}
                                <input type=\"checkbox\" id=\"htype\" checked name=\"htype[]\" value=\"{{ v }}\"> {{ v }}
                                {% else %}
                                <input type=\"checkbox\" id=\"htype\" name=\"htype[]\" value=\"{{ v }}\"> {{ v }}
                                {% endif %}
                            </label>
                            {% endfor %}
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">产权类型</label>
                        <div class=\"col-sm-10\">
                            {% for k,v in prtype %}
                            <label class=\"radio-inline\">
                                {% if data.prtype == k and data.prtype is defined %}
                                <input type=\"radio\" name=\"prtype\" checked value=\"{{ k }}\"> {{ v }}
                                {% else %}
                                <input type=\"radio\" name=\"prtype\" value=\"{{ k }}\"> {{ v }}
                                {% endif %}
                            </label>
                            {% endfor %}
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">房屋类型</label>
                        <div class=\"col-sm-10\">
                            {% for k,v in house_type %}
                            <label class=\"radio-inline\">
                                {% if data.house_type == k and data.house_type is defined %}
                                <input type=\"radio\" checked name=\"house_type\" value=\"{{ k }}\"> {{ v }}
                                {% else %}
                                <input type=\"radio\"  name=\"house_type\" value=\"{{ k }}\"> {{ v }}
                                {% endif %}
                            </label>
                            {% endfor %}
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">物业类型</label>
                        <div class=\"col-sm-10\">
                            {% for k,v in ptype %}
                            <label class=\"checkbox-inline\">
                                {% if v in data.ptype %}
                                <input type=\"checkbox\" id=\"ptype\" checked name=\"ptype[]\" value=\"{{ v }}\"> {{ v }}
                                {% else %}
                                <input type=\"checkbox\" id=\"ptype\" name=\"ptype[]\" value=\"{{ v }}\"> {{ v }}
                                {% endif %}
                            </label>
                            {% endfor %}
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"col-sm-offset-2 col-sm-10\">
                            <input type=\"button\" onclick=\"check_info(3,'{{data.id}}')\" class=\"btn btn-success\" value=\"审核通过\"/>
                            <input type=\"button\" onclick=\"check_info(2,'{{data.id}}')\" class=\"btn btn-success\" value=\"拒绝通过\"/>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>
<!-- End Page -->
{% endblock %}
{% block js %}
<script src=\"/apps/admin/views/viewNewHouse/js/houseDetail.js\"></script>
{% endblock %}", "viewNewHouse/houseDetail.html", "/home/wwwroot/dev.tefangw.vag/wwwroot/apps/admin/views/viewNewHouse/houseDetail.html");
    }
}
