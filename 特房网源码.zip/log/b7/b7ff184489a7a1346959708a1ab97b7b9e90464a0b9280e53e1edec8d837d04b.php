<?php

/* loan/index.html */
class __TwigTemplate_033c88348b94acee2912c35f2479bf79d322a4f29708de52cf50ef1314d0638a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.html", "loan/index.html", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
            'js' => array($this, 'block_js'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "
";
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "<!-- Page -->
<div class=\"page animsition\">
    <div class=\"page-header\">
        <h1 class=\"page-title\"># 金融贷款</h1>
    </div>
    <div class=\"page-content\">
        <div class=\"panel\">
            <div class=\"panel-heading\">
                <h3 class=\"panel-title\">@ 金融贷款列表</h3>
            </div>
            <ul class=\"nav nav-pills\" style=\"margin-left: 25px;\">
                <li role=\"presentation\" ";
        // line 17
        if ((($context["status"] ?? null) == 0)) {
            echo "class=\"active\"";
        }
        echo "><a href=\"/admin/loan/index/status/0\">未读</a></li>
                <li role=\"presentation\" ";
        // line 18
        if ((($context["status"] ?? null) == 1)) {
            echo "class=\"active\"";
        }
        echo "><a href=\"/admin/loan/index/status/1\">已读</a></li>

            <form action=\"/admin/loan/index/status/";
        // line 20
        echo twig_escape_filter($this->env, ($context["status"] ?? null), "html", null, true);
        echo "\" method=\"POST\">
        <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
          <input type=\"text\" class=\"form-control\" name=\"types\" placeholder=\"贷款类型\">
          <span class=\"input-group-btn\">
            <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
          </span>
        </div>
        <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
          <input type=\"text\" class=\"form-control\" name=\"phone\" placeholder=\"请输入电话号码\">
          <span class=\"input-group-btn\">
            <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
          </span>
        </div>
      </form>
       </ul>
            <div class=\"panel-body\">
                <table class=\"table table-hover\">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>姓名</th>
                        <th>联系电话</th>
                        <th>预计贷款费用</th>
                        <th>贷款类型</th>
                        <th>时间</th>
                        <th>操作</th>
                    </tr>
                    </thead>
                    <tbody>
                    ";
        // line 49
        if (($context["data"] ?? null)) {
            // line 50
            echo "                    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["data"] ?? null));
            foreach ($context['_seq'] as $context["k"] => $context["v"]) {
                // line 51
                echo "                    <tr>
                        <td>
                            ";
                // line 53
                if ((($context["status"] ?? null) == 4)) {
                    // line 54
                    echo "                            ";
                    if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "type", array()) == 3)) {
                        // line 55
                        echo "                            <span class=\"text-danger\">{隐藏}</span>
                            ";
                    } else {
                        // line 57
                        echo "                            <span class=\"text-success\">{展示}</span>
                            ";
                    }
                    // line 59
                    echo "                            ";
                }
                // line 60
                echo "                        </td>

                        <td>";
                // line 62
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "cname", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 63
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "phone", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 64
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "money", array()), "html", null, true);
                echo "</td>
                        <td>
                         ";
                // line 66
                if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "type", array()) == 0)) {
                    // line 67
                    echo "
                        <span>抵押贷款</span>
                         ";
                } elseif ((twig_get_attribute($this->env, $this->getSourceContext(),                 // line 69
$context["v"], "type", array()) == 1)) {
                    // line 70
                    echo "                         <span>信用贷款</span>
                         ";
                } else {
                    // line 72
                    echo "                         <span>组合贷款</span>
                          ";
                }
                // line 74
                echo "


                        </td>
                        <td>";
                // line 78
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "ctime", array()), "Y-m-d H:i"), "html", null, true);
                echo "</td>
                        <td>
                        ";
                // line 80
                if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "status", array()) == 0)) {
                    // line 81
                    echo "                             <!-- <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"update_info(";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                    echo ");\">修改</button> -->
                            <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"status(";
                    // line 82
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                    echo ");\">已读</button>
                        ";
                } elseif ((twig_get_attribute($this->env, $this->getSourceContext(),                 // line 83
$context["v"], "status", array()) == 1)) {
                    // line 84
                    echo "                              <button type=\"button\" class=\"btn btn-default btn-xs\" onclick=\"del_info(";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["v"], "id", array()), "html", null, true);
                    echo ");\">删除</button>
                            ";
                }
                // line 86
                echo "

                        </td>
                    </tr>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['k'], $context['v'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 91
            echo "                    ";
        } else {
            // line 92
            echo "                    <tr>
                        <td colspan=\"4\">
                            <blockquote>
                                <p>暂无数据 :(</p>
                            </blockquote>
                        </td>
                    </tr>
                    ";
        }
        // line 100
        echo "                    </tbody>
                </table>
                <div style=\"float: right;\">
                    ";
        // line 104
        echo "                    ";
        echo ($context["page"] ?? null);
        echo "
                    ";
        // line 106
        echo "                </div>

            </div>
        </div>
    </div>
</div>
<!-- End Page -->
";
    }

    // line 115
    public function block_js($context, array $blocks = array())
    {
        // line 116
        echo "<script src=\"/apps/admin/views/loan/js/index.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "loan/index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  236 => 116,  233 => 115,  222 => 106,  217 => 104,  212 => 100,  202 => 92,  199 => 91,  189 => 86,  183 => 84,  181 => 83,  177 => 82,  172 => 81,  170 => 80,  165 => 78,  159 => 74,  155 => 72,  151 => 70,  149 => 69,  145 => 67,  143 => 66,  138 => 64,  134 => 63,  130 => 62,  126 => 60,  123 => 59,  119 => 57,  115 => 55,  112 => 54,  110 => 53,  106 => 51,  101 => 50,  99 => 49,  67 => 20,  60 => 18,  54 => 17,  41 => 6,  38 => 5,  33 => 3,  30 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layouts.html\" %}
{% block css %}

{% endblock %}
{% block content %}
<!-- Page -->
<div class=\"page animsition\">
    <div class=\"page-header\">
        <h1 class=\"page-title\"># 金融贷款</h1>
    </div>
    <div class=\"page-content\">
        <div class=\"panel\">
            <div class=\"panel-heading\">
                <h3 class=\"panel-title\">@ 金融贷款列表</h3>
            </div>
            <ul class=\"nav nav-pills\" style=\"margin-left: 25px;\">
                <li role=\"presentation\" {% if status == 0 %}class=\"active\"{% endif %}><a href=\"/admin/loan/index/status/0\">未读</a></li>
                <li role=\"presentation\" {% if status == 1 %}class=\"active\"{% endif %}><a href=\"/admin/loan/index/status/1\">已读</a></li>

            <form action=\"/admin/loan/index/status/{{ status }}\" method=\"POST\">
        <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
          <input type=\"text\" class=\"form-control\" name=\"types\" placeholder=\"贷款类型\">
          <span class=\"input-group-btn\">
            <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
          </span>
        </div>
        <div class=\"input-group\" style=\"width: 250px;float: right;margin-right: 30px;\">
          <input type=\"text\" class=\"form-control\" name=\"phone\" placeholder=\"请输入电话号码\">
          <span class=\"input-group-btn\">
            <button type=\"submit\" class=\"btn btn-primary\"><i class=\"icon wb-search\" aria-hidden=\"true\"></i></button>
          </span>
        </div>
      </form>
       </ul>
            <div class=\"panel-body\">
                <table class=\"table table-hover\">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>姓名</th>
                        <th>联系电话</th>
                        <th>预计贷款费用</th>
                        <th>贷款类型</th>
                        <th>时间</th>
                        <th>操作</th>
                    </tr>
                    </thead>
                    <tbody>
                    {% if data %}
                    {% for k,v in data %}
                    <tr>
                        <td>
                            {% if status == 4 %}
                            {% if v.type == 3 %}
                            <span class=\"text-danger\">{隐藏}</span>
                            {% else %}
                            <span class=\"text-success\">{展示}</span>
                            {% endif %}
                            {% endif %}
                        </td>

                        <td>{{ v.cname }}</td>
                        <td>{{ v.phone }}</td>
                        <td>{{v.money}}</td>
                        <td>
                         {% if v.type == 0%}

                        <span>抵押贷款</span>
                         {% elseif v.type == 1%}
                         <span>信用贷款</span>
                         {% else %}
                         <span>组合贷款</span>
                          {% endif %}



                        </td>
                        <td>{{ v.ctime|date(\"Y-m-d H:i\") }}</td>
                        <td>
                        {% if v.status == 0 %}
                             <!-- <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"update_info({{ v.id }});\">修改</button> -->
                            <button type=\"button\" class=\"btn btn-primary btn-xs\" onclick=\"status({{ v.id }});\">已读</button>
                        {% elseif v.status == 1 %}
                              <button type=\"button\" class=\"btn btn-default btn-xs\" onclick=\"del_info({{ v.id }});\">删除</button>
                            {% endif %}


                        </td>
                    </tr>
                    {% endfor %}
                    {% else %}
                    <tr>
                        <td colspan=\"4\">
                            <blockquote>
                                <p>暂无数据 :(</p>
                            </blockquote>
                        </td>
                    </tr>
                    {% endif %}
                    </tbody>
                </table>
                <div style=\"float: right;\">
                    {% autoescape false %}
                    {{ page }}
                    {% endautoescape %}
                </div>

            </div>
        </div>
    </div>
</div>
<!-- End Page -->
{% endblock %}

{% block js %}
<script src=\"/apps/admin/views/loan/js/index.js\"></script>
{% endblock %}", "loan/index.html", "/home/wwwroot/dev.tefangw.vag/wwwroot/apps/admin/views/loan/index.html");
    }
}
