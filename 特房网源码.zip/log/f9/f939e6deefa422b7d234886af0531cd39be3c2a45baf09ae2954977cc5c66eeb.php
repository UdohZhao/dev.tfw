<?php

/* newHouseMain/add.html */
class __TwigTemplate_711659c4571f7a22dc3f982d18821b0b8a916d887e4ad444d3a364ca4987579b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.html", "newHouseMain/add.html", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
            'js' => array($this, 'block_js'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "
";
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "<!-- Page -->
<div class=\"page animsition\">
  <div class=\"page-header\">
    <h1 class=\"page-title\"># 房屋管理</h1>
  </div>
  <div class=\"page-content\">
    <div class=\"panel\">
      <div class=\"panel-heading\">
        <h3 class=\"panel-title\">@ 添加主力户型</h3>
      </div>
      <div class=\"panel-body\">
        <form class=\"form-horizontal\" id=\"newHouseMainForm\" action=\"/admin/newHouseMain/add/nhcid/";
        // line 17
        echo twig_escape_filter($this->env, ($context["nhcid"] ?? null), "html", null, true);
        echo "\" method=\"post\">
          <div class=\"form-group\">
            <label for=\"inputEmail3\" class=\"col-sm-2 control-label\">封面图片路径</label>
            <div class=\"col-sm-10\">
                <div id=\"preview\">
                    <img id=\"imghead\" border=\"0\" src=\"/apps/admin/views/assets/images/photo_icon.png\" width=\"90\" height=\"90\" onclick=\"\$('#previewImg').click();\">
                </div>
                <input type=\"file\" onchange=\"previewImage(this)\" style=\"display: none;\" id=\"previewImg\" name=\"cover_path\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">户型</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"house_type_name\" placeholder=\"请输入户型\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">名称</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"cname\" placeholder=\"请输入名称\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">特点</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"trait\" placeholder=\"请输入户型，以英文逗号分隔，例如：AAA,BBB,CCC\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">价格</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"price\" placeholder=\"请输入价格\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">销售类型</label>
            <div class=\"col-sm-10\">
              <label class=\"radio-inline\">
                <input type=\"radio\" name=\"sell_type\" value=\"0\" checked=\"checked\"> 主推
              </label>
              <label class=\"radio-inline\">
                <input type=\"radio\" name=\"sell_type\" value=\"1\"> 在售
              </label>
              <label class=\"radio-inline\">
                <input type=\"radio\" name=\"sell_type\" value=\"2\"> 售完
              </label>
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">建筑面积</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"covered_area\" placeholder=\"请输入建筑面积\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">朝向</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"orientation\" placeholder=\"请输入朝向\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">首付占比</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"down_payment\" placeholder=\"首付占比？以英文逗号分隔，例如：AAA,BBB,CCC\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">月供</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"mip\" placeholder=\"请输入月供\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">户型解析</label>
            <div class=\"col-sm-10\">
              <!-- 加载编辑器的容器 -->
              <script id=\"container\" name=\"analysis\" type=\"text/plain\" style=\"height: 300px;\"></script>
            </div>
          </div>
          <div class=\"form-group\">
            <div class=\"col-sm-offset-2 col-sm-10\">
              <button type=\"submit\" class=\"btn btn-success\">添加一条</button>
              <button type=\"button\" class=\"btn btn-default\" onclick=\"gotoNhc();\">前往待审核列表</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- End Page -->
";
    }

    // line 109
    public function block_js($context, array $blocks = array())
    {
        // line 110
        echo "<script src=\"/apps/admin/views/newHouseMain/js/add.js\"></script>
<!-- 配置文件 -->
<script type=\"text/javascript\" src=\"/public/ueditor/ueditor.config.js\"></script>
<!-- 编辑器源码文件 -->
<script type=\"text/javascript\" src=\"/public/ueditor/ueditor.all.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "newHouseMain/add.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  153 => 110,  150 => 109,  54 => 17,  41 => 6,  38 => 5,  33 => 3,  30 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layouts.html\" %}
{% block css %}

{% endblock %}
{% block content %}
<!-- Page -->
<div class=\"page animsition\">
  <div class=\"page-header\">
    <h1 class=\"page-title\"># 房屋管理</h1>
  </div>
  <div class=\"page-content\">
    <div class=\"panel\">
      <div class=\"panel-heading\">
        <h3 class=\"panel-title\">@ 添加主力户型</h3>
      </div>
      <div class=\"panel-body\">
        <form class=\"form-horizontal\" id=\"newHouseMainForm\" action=\"/admin/newHouseMain/add/nhcid/{{ nhcid }}\" method=\"post\">
          <div class=\"form-group\">
            <label for=\"inputEmail3\" class=\"col-sm-2 control-label\">封面图片路径</label>
            <div class=\"col-sm-10\">
                <div id=\"preview\">
                    <img id=\"imghead\" border=\"0\" src=\"/apps/admin/views/assets/images/photo_icon.png\" width=\"90\" height=\"90\" onclick=\"\$('#previewImg').click();\">
                </div>
                <input type=\"file\" onchange=\"previewImage(this)\" style=\"display: none;\" id=\"previewImg\" name=\"cover_path\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">户型</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"house_type_name\" placeholder=\"请输入户型\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">名称</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"cname\" placeholder=\"请输入名称\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">特点</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"trait\" placeholder=\"请输入户型，以英文逗号分隔，例如：AAA,BBB,CCC\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">价格</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"price\" placeholder=\"请输入价格\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">销售类型</label>
            <div class=\"col-sm-10\">
              <label class=\"radio-inline\">
                <input type=\"radio\" name=\"sell_type\" value=\"0\" checked=\"checked\"> 主推
              </label>
              <label class=\"radio-inline\">
                <input type=\"radio\" name=\"sell_type\" value=\"1\"> 在售
              </label>
              <label class=\"radio-inline\">
                <input type=\"radio\" name=\"sell_type\" value=\"2\"> 售完
              </label>
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">建筑面积</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"covered_area\" placeholder=\"请输入建筑面积\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">朝向</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"orientation\" placeholder=\"请输入朝向\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">首付占比</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"down_payment\" placeholder=\"首付占比？以英文逗号分隔，例如：AAA,BBB,CCC\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">月供</label>
            <div class=\"col-sm-10\">
              <input type=\"text\" class=\"form-control\" name=\"mip\" placeholder=\"请输入月供\">
            </div>
          </div>
          <div class=\"form-group\">
            <label for=\"inputPassword3\" class=\"col-sm-2 control-label\">户型解析</label>
            <div class=\"col-sm-10\">
              <!-- 加载编辑器的容器 -->
              <script id=\"container\" name=\"analysis\" type=\"text/plain\" style=\"height: 300px;\"></script>
            </div>
          </div>
          <div class=\"form-group\">
            <div class=\"col-sm-offset-2 col-sm-10\">
              <button type=\"submit\" class=\"btn btn-success\">添加一条</button>
              <button type=\"button\" class=\"btn btn-default\" onclick=\"gotoNhc();\">前往待审核列表</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- End Page -->
{% endblock %}
{% block js %}
<script src=\"/apps/admin/views/newHouseMain/js/add.js\"></script>
<!-- 配置文件 -->
<script type=\"text/javascript\" src=\"/public/ueditor/ueditor.config.js\"></script>
<!-- 编辑器源码文件 -->
<script type=\"text/javascript\" src=\"/public/ueditor/ueditor.all.js\"></script>
{% endblock %}", "newHouseMain/add.html", "/home/wwwroot/dev.tefangw.vag/wwwroot/apps/admin/views/newHouseMain/add.html");
    }
}
